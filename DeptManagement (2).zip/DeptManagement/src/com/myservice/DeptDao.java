package com.myservice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DeptDao {
	
	private Connection conn;
	
	public DeptDao() {
		try {
			//1st step
			System.out.println("Registering Driver ....");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver registered....");
			
			//2nd step
			System.out.println("Trying to connect...");
			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:xe","scott","tiger");
			System.out.println("Connected to the DB..."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<Dept> getAllDepts() {
		
		ArrayList<Dept> allDepts = new ArrayList<Dept>();
		
		try {
			//3rd step is what ???
			Statement st = conn.createStatement();
			
			System.out.println("Statement created.."+st);
			
			//CRUD
			ResultSet rs = st.executeQuery("select deptno,dname,loc from dept");
			
			System.out.println("Got the result : "+rs);
			
			while(rs.next()) //now rs is pointing to dept
			{
				//single blank object
				Dept deptRef = new Dept();

				//now fill up this deptRef object with DB value
				deptRef.setDeptNumber(  rs.getInt(1)  );
				deptRef.setDeptName (rs.getString(2));
				deptRef.setDeptLocation( rs.getString(3) );
				
				//this filled object to be added in the linked list
				allDepts.add(deptRef);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allDepts;
	}
	
	public Dept getDept(int deptno) {
		
		Dept deptRef =  null;
		
		try {
			//3rd step is what ???
			Statement st = conn.createStatement();
			
			System.out.println("Statement created.."+st);
			
			//CRUD
			ResultSet rs = st.executeQuery("select deptno,dname,loc from dept where deptno="+deptno);
			
			System.out.println("Got the result : "+rs);
			
			if(rs.next()) //now rs is pointing to dept
			{
				//single blank object
				deptRef = new Dept();

				//now fill up this deptRef object with DB value
				deptRef.setDeptNumber(  rs.getInt(1)  );
				deptRef.setDeptName (rs.getString(2));
				deptRef.setDeptLocation( rs.getString(3) );
				
				//this filled object to be added in the linked list
				//allDepts.add(deptRef);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deptRef;
	}
	
	public void  insertIntoDept(Dept dref) {
		
		try {
			//3rd step is what ???
			PreparedStatement pst = conn.prepareStatement("insert into dept values (?,?,?)");
			
			System.out.println("PreparedStatement created.."+pst);
			
			pst.setInt(1, dref.getDeptNumber());
			pst.setString(2, dref.getDeptName());
			pst.setString(3, dref.getDeptLocation());
			int row = pst.executeUpdate();
			System.out.println("inserted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void  updateDept(Dept dref) {
		
		try {
			//3rd step is what ???
			PreparedStatement pst = conn.prepareStatement("update dept set dname=?, loc=? where deptno=?");
			
			System.out.println("PreparedStatement created.."+pst);
			
			
			pst.setString(1, dref.getDeptName());
			pst.setString(2, dref.getDeptLocation());
			pst.setInt(3, dref.getDeptNumber());
			
			int row = pst.executeUpdate();
			System.out.println("updated..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void  deleteDept(int dno) {
		
		try {
			//3rd step is what ???
			PreparedStatement pst = conn.prepareStatement("delete from dept where deptno=?");
			
			System.out.println("PreparedStatement created.."+pst);
			pst.setInt(1, dno);
			
			int row = pst.executeUpdate();
			System.out.println("deleted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
