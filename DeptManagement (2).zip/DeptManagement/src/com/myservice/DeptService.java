package com.myservice;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// http://ip:port/DeptManagement/DeptService/rest/depts
//intermediate program as 
//ServletContainer from jersey framework

/*for REST
 *                         web.xml
 *             ProjectFolder   |   @Path       
http://ip:port/DeptManagement/rest/depts 		<-GET
http://ip:port/DeptManagement/rest/depts/10 	<-GET
http://ip:port/DeptManagement/rest/depts/10 	<-DELETE

http://ip:port/DeptManagement/rest/depts 		<-POST
http://ip:port/DeptManagement/rest/depts 		<-PUT


*/

@Path("/depts")
public class DeptService {
	
	DeptDao dd = new DeptDao();

	@GET
	//@Path("/getall")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Dept> getDepts() {
		System.out.println("Inside depts");
		return dd.getAllDepts();
	}  
	
	 
	@GET
	@Path("/{dno}")
	@Produces(MediaType.APPLICATION_JSON)
	public Dept getDept(@PathParam("dno") int dno) {
		System.out.println("Inside get/{dno}");
		return dd.getDept(dno);
	}
	
	@DELETE
	@Path("/{dno}")
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteDept(@PathParam("dno") int dno) {
		
		System.out.println("Inside delete/{dno}");
		dd.deleteDept(dno);
	}
	
	
	
	@POST
	//@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	public void addDepts(Dept dept) {
		dd.insertIntoDept(dept);
	}
	
	@PUT
	//@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateDept(Dept dept) {
		dd.updateDept(dept);
	}
 
	
}

/* CONTROLLER
 * @Path("/DeptService") <-- url pattern in web.xml
public class DeptServlet extends HttpServlet {
	
	DeptDao dd ;
	
	init() { dd = = new DeptDao(); }
	
	service() { List lst =  getDepts() 
		handover this lst to jsp page to VIEW
	}
	
	destroy() { }
	
	
	public List<Dept> getDepts() { // MODEL
	//if some logic is here then its better approach
		return dd.getAllDepts();
	}
}
 * 
 */
