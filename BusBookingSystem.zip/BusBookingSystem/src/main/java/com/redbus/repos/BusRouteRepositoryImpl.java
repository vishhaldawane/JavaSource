package com.redbus.repos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusRoute;
import com.redbus.pojos.BusType;

@Repository
public class BusRouteRepositoryImpl implements BusRouteRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<BusRoute> getAllBusRoutes() {
			Query query = entityManager.createQuery(" from BusRoute");
			List<BusRoute> busRoutes = query.getResultList();
			return busRoutes;
	}
}
