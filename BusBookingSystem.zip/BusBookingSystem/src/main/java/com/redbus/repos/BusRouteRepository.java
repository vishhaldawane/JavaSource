package com.redbus.repos;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusRoute;

@Repository
public interface BusRouteRepository {
	List<BusRoute> getAllBusRoutes();
}
