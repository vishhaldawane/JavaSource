package com.redbus.repos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.Registration;

@Repository
public class RegistrationRepositoryImpl implements RegistrationRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<Registration> getAllRegistrations() {
		Query query = entityManager.createQuery(" from Registration");
		List<Registration> regestrations = query.getResultList();
		return regestrations;
	}
}
