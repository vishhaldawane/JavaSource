package com.redbus.repos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.Registration;
import com.redbus.pojos.Reservation;

@Repository
public class ReservationRepositoryImpl implements ReservationRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<Reservation> getAllReservations() {
		Query query = entityManager.createQuery(" from Reservation");
		List<Reservation> allReservations = query.getResultList();
		return allReservations;
	}
}
