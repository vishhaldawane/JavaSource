package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the BUSTYPE database table.
 * 
 */
@Entity
@NamedQuery(name="BusType.findAll", query="SELECT b FROM BusType b")
public class BusType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String busnumber;

	private String busstatus;

	private String facilities;

	private String typeofbus;

	//bi-directional many-to-one association to BusRoute
	@OneToMany(mappedBy="bustype", cascade={CascadeType.ALL}, fetch=FetchType.EAGER)
	private Set<BusRoute> busroutes;

	public BusType() {
	}

	public String getBusnumber() {
		return this.busnumber;
	}

	public void setBusnumber(String busnumber) {
		this.busnumber = busnumber;
	}

	public String getBusstatus() {
		return this.busstatus;
	}

	public void setBusstatus(String busstatus) {
		this.busstatus = busstatus;
	}

	public String getFacilities() {
		return this.facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	public String getTypeofbus() {
		return this.typeofbus;
	}

	public void setTypeofbus(String typeofbus) {
		this.typeofbus = typeofbus;
	}

	public Set<BusRoute> getBusroutes() {
		return this.busroutes;
	}

	public void setBusroutes(Set<BusRoute> busroutes) {
		this.busroutes = busroutes;
	}

	public BusRoute addBusroute(BusRoute busroute) {
		getBusroutes().add(busroute);
		busroute.setBustype(this);

		return busroute;
	}

	public BusRoute removeBusroute(BusRoute busroute) {
		getBusroutes().remove(busroute);
		busroute.setBustype(null);

		return busroute;
	}

}