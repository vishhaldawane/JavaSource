package com.redbus;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.redbus.pojos.BusRoute;
import com.redbus.pojos.BusType;
import com.redbus.pojos.Registration;
import com.redbus.pojos.Reservation;
import com.redbus.repos.BusRouteRepository;
import com.redbus.repos.BusTypeRepository;
import com.redbus.repos.RegistrationRepository;
import com.redbus.repos.ReservationRepository;

@SpringBootTest
class BusBookingSystemApplicationTests {

	
	@Autowired
	BusTypeRepository busTypeRepo;
	
	@Autowired
	BusRouteRepository busRouteRepo;
	
	@Autowired
	RegistrationRepository regRepo;
	
	@Autowired
	ReservationRepository reserveRepo;
	
	
	@Test
	void getAllBusTypes() {
		//BUSNUMBER            TYPEOFBUS            BUSSTATUS            FACILITIES
		List<BusType> busTypes = busTypeRepo.getAllBusTypes();
		for (BusType busType : busTypes) {
			System.out.println(busType.getBusnumber()+"\t"+busType.getTypeofbus()+"\t"+busType.getBusstatus()+"\t"+busType.getFacilities());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}
	
	@Test
	void getAllBusRoutes() {
	//	 ROUTENO BUSNUMBER            BOARDING             DROPPING               DISTANCE STARTTIME         ENDTIME               FARE
		List<BusRoute> busRoutes = busRouteRepo.getAllBusRoutes();
		for (BusRoute busRoute : busRoutes) {
			System.out.println(busRoute.getRouteno());
			System.out.println(busRoute.getBustype().getBusnumber());
			System.out.println(busRoute.getBoarding());
			System.out.println(busRoute.getDropping());
			System.out.println(busRoute.getDistance());
			System.out.println(busRoute.getStarttime());
			System.out.println(busRoute.getEndtime());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}

	@Test
	void getAllRegistrations() {
//		REGEMAIL                       PASSWORD             REGNAME         G REGPHONE   DATEOFBIR     WALLET
		List<Registration> allRegs = regRepo.getAllRegistrations();
		
		for (Registration reg: allRegs) {
			System.out.println(reg.getRegemail());
			System.out.println(reg.getPassword());
			System.out.println(reg.getRegname());
			System.out.println(reg.getGender());
			System.out.println(reg.getRegphone());
			System.out.println(reg.getDateofbirth());
			System.out.println(reg.getWallet());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}
	
	@Test
	void getAllReservations() {
//		 TICKETNO BOOKINGDA JOURNEYDA     SEATNO    ROUTENO TICKETSTAT CANCELLAT     REFUND RESCHEDUL TRANSACTIONID
		List<Reservation> allReserves = reserveRepo.getAllReservations();
		
		for (Reservation res: allReserves) {
			System.out.println("--------------------------------------");
			System.out.print("\t"+res.getTicketno());
			System.out.print("\t"+res.getBookingdate());
			System.out.print("\t"+res.getJourneydate());
			System.out.print("\t"+res.getSeatno());
			System.out.print("\t"+res.getBusroute().getRouteno());
			System.out.print("\t"+res.getTicketstatus());
			System.out.print("\t"+res.getCancellationdate());
			System.out.print("\t"+res.getRefund());
			System.out.print("\t"+res.getRescheduledate());
			System.out.print("\t"+res.getTransactionid()+"\n");
		}
		System.out.println("contextLoads succedded...");
	}
}
