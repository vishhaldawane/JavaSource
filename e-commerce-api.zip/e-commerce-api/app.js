// To use express, we require "express" module
const express = require("express");

// To connect to MongoDB database, we need mongoose module.
const mongoose = require("mongoose");
const dbConfig = require("./config/dbConfig.js");
console.log(dbConfig.url);

mongoose.connect(dbConfig.url, {useNewUrlParser: true})
               .then(() => {
                   console.log("--connected to database successfully--");
               })
               .catch((err) => {
                   console.log("Failed to connect to database: ", err);
               })

// We need to create an express server. (instance of express server)
const app = express();

// Add a body parser
const bodyParser = require("body-parser");
app.use(bodyParser.json());

const cors = require("cors");
app.use(cors());

// Add the book.routes.js file.
require("./routes/book.routes.js")(app);

// Add the cutomer.routes.js file.
require("./routes/customer.routes.js")(app);

//Add the cart.routes.js file
require("./routes/cart.routes.js")(app);

//Add the order.routes.js file
require("./routes/order.routes.js")(app);

app.get("/", (request, response) => {
    response.send(200, "Hello World!!!");
    //response.status(200).send("Hello World!!!");
})

app.listen(8000, () => {
    console.log("Express server started and running on port 8000");
})



