
const Cart = require("../models/cart.model.js");

exports.findCartByEmail = (request, response) => {
    console.log(request.params.email);
    Cart.findOne({ "email": request.params.email })
           .then((data) => {
               console.log(data);
               if(data) {
                   response.status(200).send(data);
               }
               else {
                   console.log("creating new cart");
                   let cart = new Cart({
                       items: [],
                       totalAmount: 0,
                       email: request.params.email
                   });

                   cart.save()
                         .then((data) => {
                             response.status(200).send(data);
                         })
                         .catch((err) => {
                             response.status(500).send("something went wrong...", err);
                         })
               }
           })
           .catch((err) => {
                response.status(500).send("something went wrong...", err);
           })
}

exports.updateCart = (request, response) => {
    Cart.findOneAndUpdate({ email: request.body.email }, {
       $set: {
             items: request.body.items,
             totalAmount: request.body.totalAmount
       }   
    })
    .then((data) => {
        response.status(200).send({ message: "success" });
    })
    .catch((err) => {
        response.status(500).send("something went wrong...", err);
    })
}