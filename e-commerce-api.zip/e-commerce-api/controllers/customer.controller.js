
const Customer = require("../models/customer.model.js");

exports.registerNewCustomer = (request, response) => {

    console.log(request.body);

    if(!request.body.email) {
        response.status(400).send("Please provide complete information.");
    }
    else {
        let customer = new Customer({
            name: request.body.name,
            password: request.body.password,
            email: request.body.email,
            contact: request.body.contact,
            gender: request.body.gender,
            address: {
                addressLine1: request.body.address.addressLine1,
                state: request.body.address.state,
                city: request.body.address.city,
                postalCode: request.body.address.postalCode
            },
            orders: []
        });

        customer.save()
                      .then((data) => {
                          response.status(200).send(data);
                      })
                      .catch((err) => {
                          response.status(500).send("Failed to register... ", err);
                      })
    }
} 

exports.authenticate = (request, response) => {

    if(!request.body.email) {
        response.status(400).send("Please provide complete information.")
    }
    
    else {
        let email_id = request.body.email;
        let password = request.body.password;

        Customer.findOne({"email": email_id, "password": password})
                      .then((data) => {
                          if(!data) {
                              response.status(404).send("Not found");
                          }
                          else {
                              response.status(200).send(data);
                          }
                      })
                      .catch((err) => {
                          response.status(500).send("Something went wrong...", err);
                      })
    }

}

exports.updateCustomerInfo = (request, response) => {
    console.log(request.body);
    Customer.findOneAndUpdate({ "email": request.body.email}, {
        $set: { "name": request.body.name, contact: request.body.contact,
                "address.addressLine1": request.body.address.addressLine1,
               "address.state": request.body.address.state,
               "address.city": request.body.address.city,
               "address.postalCode": request.body.address.postalCode,
                orders: request.body.orders 
               }
    }).then((data) => {
        response.status(200).send(data);
    }).catch((err) => {
        response.status(500).send("something went wrong...", err);
    })
}