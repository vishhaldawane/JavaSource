
const Book = require("../models/book.model.js");

exports.addNewBook = (request, response) => {

    // First check if request.body contains book information
    if(!request.body.bookId)
        response.status(400).send("Book information should be complete.");
    else {
        let book = new Book({
            bookId: request.body.bookId,
            imageUrl: request.body.imageUrl,
            title: request.body.title,
            authors: request.body.authors,
            category: request.body.category,
            publisher: request.body.publisher,
            noOfPages: request.body.noOfPages,
            rating: request.body.rating, 
            edition: request.body.edition,
            price: request.body.price,
            releaseDate: request.body.releaseDate
        });

        book.save()
               .then((data) => {
                   response.status(200).send("Book added successfully.");
               })
               .catch((err) => {
                   response.status(500).send("Failed to add book.", err);
               })
    }    
}

exports.findBookByCategory = (request, response) => {

    const bookCategory = request.params.category;

    Book.find({ category: bookCategory})
           .then((data) => {
               if(data.length == 0)
                    response.status(404).send("Books with specified category not found");
               else
                    response.status(200).send(data);     
           })
           .catch((err) => {
               response.status(500).send("Failed to load books", err);
           })

}

exports.findBookById = (request, response) => {

    let book_Id = request.params.bookId;
    Book.findOne({ bookId: book_Id })
           .then((data) => {
               if(data == null)
                    response.status(404).send("Book not found.");
               else
                    response.status(200).send(data);
           })
           .catch((err) => {
                response.status(500).send("Failed to load book", err);
           })
}

exports.deleteBookById = (request, response) => {

    let book_id = request.params.bookId;

    Book.findOneAndDelete({ bookId: book_id })
           .then((data) => {
               if(data == null)
                    response.status(404).send("Book not found.");
               else
                    response.status(200).send("Book is deleted.");     
           })
           .catch((err) => {
               response.status(500).send("Failed to delete a book", err);
           })

}

exports.findAllBooks = (request, response) => {

    Book.find()
           .then((data) => {
               response.status(200).send(data);
           })
           .catch((err) => {
              response.status(500).send("Failed to load books", err);
           })
}

exports.updateBookDetails = (request, response) => {

    let book_Id = request.params.bookId;
    let book_price = request.body.price;
    console.log(book_price);

    Book.findOneAndUpdate({ bookId: book_Id}, { $set: { price: book_price }})
           .then((data) => {
               console.log(data);
               if(data == null)
                   response.status(404).send("Book not found.");
              else
                   response.status(200).send("Book information updated successfully.");                        
           })
           .catch((err) => {
               response.status(500).send("Failed to update book details", err);
           })
}




