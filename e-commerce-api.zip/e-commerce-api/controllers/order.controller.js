
const Order = require("../models/order.model.js");
const OrderSequence = require("../models/order_sequence.model.js");

exports.findOrderById = (request, response) => {

    Order.findOne({ orderId: request.params.orderId})
            .then((data) => {
                response.status(200).send(data);
            })
            .catch((err) => {
                response.status(500).send("something went wrong...", err);
            }) 
}

exports.addOrder = async (request, response) => {

    var order_id;
    await OrderSequence.findOne()
                           .then((data) => {
                                order_id = Number(data.counter + 1);                                
                           })
                           .catch((err) => {
                               console.log(err);
                           })
    var cnt = Number(order_id - 1);                       
    await OrderSequence.findOneAndUpdate({ counter: cnt }, {
        $inc: { counter: 1 }
    }).then((data) => {
        console.log("successfully updated counter value...");
    }).catch((err) => {
        console.log("something went wrong...", err);
    })                     
    
    let order = new Order({
        orderId: "OD" + order_id,
        totalAmount: request.body.totalAmount,
        status: "IN_PROGRESS",
        deliveryDate: new Date(new Date().getTime()+(4*24*60*60*1000)),
        item: request.body.item
    })

    order.save()
            .then((data) => {
                response.status(200).send(data);
            })
            .catch((err) => {
                response.status(500).send("something went wrong...", err);
            })
}

exports.generateOrderSequence = (request, response) => {

    let orderSequence = new OrderSequence({
        counter: request.body.counter
    })

    orderSequence.save()
                          .then((data) => {
                              response.status(200).send(data);
                          })
                        .catch((err) => {
                            response.status(500).send("something went wrong...", err);
                        })
}