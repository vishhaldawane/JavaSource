
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let addressSchema = new Schema({
    addressLine1: String,
    state: String,
    city: String,
    postalCode: Number,
    _id: false
})

let customerSchema = new Schema({
    name: String,
    email: String,
    password: String,
    contact: Number,
    gender: String,
    address: addressSchema,
    orders: [{ type: String }]
})

module.exports = mongoose.model("Customer", customerSchema);