const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bookSchema = mongoose.model("Book").schema;

const itemSchema = new Schema({
    book: { type: bookSchema, ref: "Book"},
    quantity: Number
});

const cartSchema = new Schema({
    items: [itemSchema],
    totalAmount: Number,
    email: String
})

module.exports = mongoose.model("Cart", cartSchema);

