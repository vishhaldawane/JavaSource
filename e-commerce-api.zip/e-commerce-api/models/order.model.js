const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bookSchema = mongoose.model("Book").schema;

let itemSchema = new Schema({
    book: { type: bookSchema, ref: "Book" },
    quantity: Number
})

const orderSchema = new Schema({
    orderId: String,
    totalAmount: Number,
    status: String,
    deliveryDate: Date,
    orderPlacedDate: { type: Date, default: Date.now},
    item: itemSchema
})

module.exports = mongoose.model("Order", orderSchema);
