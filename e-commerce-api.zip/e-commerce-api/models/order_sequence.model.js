const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let orderSequenceSchema = new Schema({
    counter: Number
})

module.exports = mongoose.model("OrderSequence", orderSequenceSchema);