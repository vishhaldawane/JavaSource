
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const authorSchema = new Schema({
    firstName: String,
    lastName: String,
    _id: false
})

const bookSchema = new Schema({
    bookId: Number,
    imageUrl: String,
    title: String,
    authors: [authorSchema],
    category: String,
    publisher: String,
    noOfPages: Number,
    rating: Number,
    edition: Number,
    price: Number,
    releaseDate: {type: Date, default: Date.now}
});

module.exports = mongoose.model("Book", bookSchema);