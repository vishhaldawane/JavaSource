
module.exports = (app) => {

    const customer = require("../controllers/customer.controller.js");

    app.post("/customers", customer.registerNewCustomer);

    app.post("/customers/login", customer.authenticate);

    app.put("/customers", customer.updateCustomerInfo);
}