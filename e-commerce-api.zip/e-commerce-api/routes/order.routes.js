
module.exports = (app) => {

    const order = require("../controllers/order.controller.js");

    app.post("/orders", order.addOrder);

    app.get("/order/:orderId", order.findOrderById);

    app.post("/orderseq", order.generateOrderSequence);
}