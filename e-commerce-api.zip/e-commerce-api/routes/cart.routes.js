
module.exports = (app) => {

    const cart = require("../controllers/cart.controller.js");

    app.get("/carts/:email", cart.findCartByEmail);

    app.put("/carts", cart.updateCart);

}
