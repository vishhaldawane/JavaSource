
module.exports = (app) => {

    const book = require("../controllers/book.controller.js");
     
    // To add a new Book
    app.post("/books", book.addNewBook);

    // To find books by category
    app.get("/books/:category", book.findBookByCategory);

    // To find a book by its Id
    app.get("/book/:bookId", book.findBookById);

    // To delete a book by its Id
    app.delete("/books/:bookId", book.deleteBookById);

    // To find all books
    app.get("/books", book.findAllBooks);

    //To edit specific book
    app.put("/books/:bookId", book.updateBookDetails);
 }