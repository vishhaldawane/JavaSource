package mypojos;

import java.util.ArrayList;

//this interface would be a mandate to its
//implementation
// and will provide assurance to developers
// to have these methods in its implementation
// if this interface is ABSENT
// THEN DEVELOPERS MAY NOT ASSURE ABOUT ITS
// CRUD ACTIVITY

public interface EmployeeDAO {
	//crud methods would be declared 
	//as per suitable naming choice by you
	//ideally we keep dql dml startup names
	
	//C
	void insertEmployee(Employee empRef);

	//R
	Employee selectEmployeeByEmployeeNumber(int eno);
	//Employee selectEmployeeByDepartmentNumber(int dno);
	
	ArrayList<Employee> selectAllEmployees();

	//U
	void updateEmployee(Employee empRef);
	
	//D
	void deleteEmployee(int empno);
	
}

/*ArrayList<Employee> selectEmployeesByDepartmentNumber(int dno);
ArrayList<Employee> selectEmployeesByJob(String  job);
ArrayList<Employee> selectEmployeesByManagersEmpno(int mgr);
*/