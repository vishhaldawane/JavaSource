package mypojos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDAOImpl implements EmployeeDAO {

	private Connection conn;
	
	public EmployeeDAOImpl( ) {
		try {
			//1st step
			System.out.println("Registering Driver ....");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver registered....");
			
			//2nd step
			System.out.println("Trying to connect...");
			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:xe","scott","tiger");
			System.out.println("Connected to the DB..."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void insertEmployee(Employee empRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee selectEmployeeByEmployeeNumber(int eno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Employee> selectAllEmployees() {

				ArrayList<Employee> allEmps = new ArrayList<Employee>();
				
				try {
					//3rd step is what ???
					Statement st = conn.createStatement();
					
					System.out.println("Statement created.."+st);
					
					//CRUD
					ResultSet rs = st.executeQuery("select * from emp");
					
					System.out.println("Got the result : "+rs);
					
					while(rs.next()) //now rs is pointing to dept
					{
						//single blank object
						Employee  empRef = new Employee();

						//now fill up this deptRef object with DB value
						empRef.setEmployeeNumber(rs.getInt(1));
						empRef.setEmployeeName(rs.getString(2));
						empRef.setEmployeeJob(rs.getString(3));
						empRef.setEmployeeManager(rs.getInt(4));
						empRef.setEmployeeHireDate(rs.getDate(5));
						empRef.setEmployeeSalary(rs.getFloat(6));
						empRef.setEmployeeCommission(rs.getFloat(7));
						empRef.setEmployeeDepartmentNumber(rs.getInt(8));
						
						//this filled object to be added in the linked list
						allEmps.add(empRef);
						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				return allEmps;
	}

	@Override
	public void updateEmployee(Employee empRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmployee(int empno) {
		// TODO Auto-generated method stub

	}

}
