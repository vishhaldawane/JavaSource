package mypojos;

import java.sql.Date;

public class Employee {
	
	private int employeeNumber;
	private String employeeName;
	private String employeeJob;
	private int employeeManager;
	private Date employeeHireDate;
	private double employeeSalary;
	private double employeeCommission;
	private int employeeDepartmentNumber;
	
	public Employee() {
		super();
		System.out.println("Employee() ctor..");
	}
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeJob() {
		return employeeJob;
	}

	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}

	public int getEmployeeManager() {
		return employeeManager;
	}

	public void setEmployeeManager(int employeeManager) {
		this.employeeManager = employeeManager;
	}

	public Date getEmployeeHireDate() {
		return employeeHireDate;
	}

	public void setEmployeeHireDate(Date employeeHireDate) {
		this.employeeHireDate = employeeHireDate;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public double getEmployeeCommission() {
		return employeeCommission;
	}

	public void setEmployeeCommission(double employeeCommission) {
		this.employeeCommission = employeeCommission;
	}

	public int getEmployeeDepartmentNumber() {
		return employeeDepartmentNumber;
	}

	public void setEmployeeDepartmentNumber(int employeeDepartmentNumber) {
		this.employeeDepartmentNumber = employeeDepartmentNumber;
	}

	
	
	
	
}
