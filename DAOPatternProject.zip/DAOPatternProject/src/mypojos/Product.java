package mypojos; //plain old java object

//this "class Department" is a proxy of your "Dept Table"
public class Product {

	//DEPTNO DNAME          LOC
	private int productId ; //proxy of deptno column
	private String productName; //proxy of dname column

		
	public Product() {
		super();
		System.out.println("Product ctor...");
	}
	
	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}




	
	
	
}
