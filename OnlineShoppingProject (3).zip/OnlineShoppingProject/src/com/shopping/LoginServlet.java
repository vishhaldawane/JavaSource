package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
      
	Connection conn;
	ResultSet rs;
	Statement st;
	
    public LoginServlet() {
        super();

    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
        try {
    		
    			System.out.println("Loading the driver...");
    			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
    			System.out.println("Driver loaded...");
    			
    			//DESKTOP-EPTT35F
    			System.out.println("\nTrying to connect to the db");
    									//http://www.google.com:9900/index.jsp
    									//mainpro:organ:thin:@  ip : dbport : instancename
    			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:XE", "scott", "tiger");
    			System.out.println("Connected to the db : "+conn);
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long userid = Long.parseLong(request.getParameter("userid"));
		String password = request.getParameter("pass");
		
	
		try
		{
			System.out.println("\nTrying to create statement");
			//	java.sql.Statement
			st = conn.createStatement();
			System.out.println("Statement created...");
			
			System.out.println("\nTrying to fire the query....");
			String myQuery = "select * from login where userid="+userid+" and password='"+password+"'";
			rs = st.executeQuery(myQuery);
			
			System.out.println("Query fired and got the result...");
			
			System.out.println("\nProcess the result...");
			PrintWriter pw = response.getWriter();
			//PrintWriter pw = response.getWriter(); 
			pw.println("<h3>Showing User Verification Status </h3>");
			
			//rs can be a cursor like variable here
			//while means like a cursor looping 
			
			
			
			if(rs.next()) //rs.next() means goto the next record
			{
				pw.println("User PRESENT");
				//u can dispatch to a jsp / html or a servlet from here 
				RequestDispatcher rd = request.getRequestDispatcher("/Welcome.html");
				rd.forward(request, response); //jump to this page
			}
			else {
				pw.println("User DOES NOT EXIST"
						+ "<div align='left'>"
						+ "<a href='register.html'>Sign-Up</a> <br>"
						+ "</div>");
			}
			pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
		}
		catch(SQLException e) {
			System.out.println("Problem1 : "+e);
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println("Problem2 :     "+e);
			//e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
