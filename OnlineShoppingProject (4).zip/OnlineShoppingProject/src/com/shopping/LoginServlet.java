package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.Login;
import com.shopping.dao.LoginDAOImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
      
	
	LoginDAOImpl ldi ; //hasA
	
    public LoginServlet() {        super();
    	System.out.println("LoginServlet() ctor...");
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
    	System.out.println("LoginServlet: init() ");
    	
    	ldi = new LoginDAOImpl();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//read userid+password from html form
		long userid = Long.parseLong(request.getParameter("userid"));
		String password = request.getParameter("pass");
		System.out.println("\nLoginServlet: doGet() Process the result...");
		PrintWriter pw = response.getWriter();
		//PrintWriter pw = response.getWriter(); 
		pw.println("<h3>Showing User Verification Status </h3>");
		//rs can be a cursor like variable here
		//while means like a cursor looping 
								//pass these html values here
		Login logDet = ldi.selectLoginByIdAndPassword(userid, password);
		
		if(logDet!=null) //rs.next() means goto the next record
		{
			pw.println("User PRESENT");
			//u can dispatch to a jsp / html or a servlet from here 
			RequestDispatcher rd = request.getRequestDispatcher("/Welcome.html");
			rd.forward(request, response); //jump to this page
		}
		else {
			pw.println("User DOES NOT EXIST"
					+ "<div align='left'>"
					+ "<a href='register.html'>Sign-Up</a> <br>"
					+ "</div>");
		}
		pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
