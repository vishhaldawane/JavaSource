public class SpringTest {
	public static void main(String[] args) {
		Plate fp = Kitchen.getFoodPlate(); 	fp.fun();
		System.out.println("fp is ready : "+fp);
	}
}
class Rice  { } class Roti  { } class Daal   { } class Salad { }  
class Papad { } class Sweet { } class Pickle { } class Lassi { } 
class Sabjee{ } class Plate{	void fun() { }  }
class FoodPlate extends Plate
{
	Rice r = new Rice();  Daal d = new Daal();Salad s = new Salad();
	Papad p = new Papad();	Sweet sw = new Sweet(); Pickle pk = new Pickle();
	Sabjee sb = new Sabjee();
	void fun() {
		System.out.println("Eating Rice "+r+" with Daal   "+d);
	}
}
class Kitchen {
	static FoodPlate getFoodPlate() {
		return new FoodPlate();
	}
}