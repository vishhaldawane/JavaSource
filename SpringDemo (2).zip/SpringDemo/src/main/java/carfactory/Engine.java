package carfactory;

import pistonunitfactory.Piston;

public class Engine {
	
	Piston pist;
	//
	//
	
	public Engine(Piston p) {
		System.out.println("Engine ctor");
		pist = p;
	}
}