import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bank.SavingsAccount;
import carcylinderfactory.Cylinder;
import carfactory.Engine;
import carshowroom.Car;
import common.Flight;
import pistonunitfactory.Piston;
import xml.FlightRepositoryImpl;

/*
 

CREATE TABLE FLIGHTS_TEST
(FLIGHTNO VARCHAR(10),
CARRIER VARCHAR(30),
KAHASE VARCHAR(30),
KAHATAK VARCHAR(30))

INSERT INTO FLIGHTS_TEST VALUES('JL-120','JET AIRWAYS','MUMBAI','JAIPUR');
INSERT INTO FLIGHTS_TEST VALUES('KL-102','KINGFISHER','DELHI','MUMBAI');
INSERT INTO FLIGHTS_TEST VALUES('AI-229','INDIAN','KOLKATA','DELHI');
INSERT INTO FLIGHTS_TEST VALUES('SP-109','SPICEJET','CHENNAI','MUMBAI');
INSERT INTO FLIGHTS_TEST VALUES('GO-120','GO AIR','MUMBAI','BANGALORE');
INSERT INTO FLIGHTS_TEST VALUES('GO-121','GO AIR','MUMBAI','GOA');
INSERT INTO FLIGHTS_TEST VALUES('JL-137','JET AIRWAYS','GOA','MUMBAI');

---------------------------

1. pom.xml

		spring-core
		spring-jdbc
		spring-context
		spring-test
		spring-context-support
		
2. spring.xml
		declare 2 beans there

		1. id="ds"
		a. DataSource
			|
		org.springframework.jdbc.
		datasource.DriverManagerDataSource

		- invoke all the required setter methods
		<property name="driverClassName">driver
		<property name="url"> the url
		<property name="username"> username
		<property name="password"> password

		2. id="flightRepo"
			|
		   xml.FlightRepositoryImpl
		 - invoke the setter method
		<property name="dataSource" ref="ds"> 		

  
 */

class CarShowRoom
{
	//xml would govern the configuration
	
	static Car getACar() {
		Cylinder cyl = new Cylinder(20); //Load Driver
		Piston pist = new Piston(cyl); //Connection
		Engine eng = new Engine(pist); //Statement 
		Car myCar = new Car(eng); //Result rs;
		return myCar;
	}
}
public class CarTest {
	public static void main(String[] args) {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		
		FlightRepositoryImpl fr = (FlightRepositoryImpl) container.getBean("flightRepo");
		
		List<Flight> flightList = fr.getAvailableFlights();
		for (Flight flight : flightList) {
			System.out.println("Flight : "+flight);
		}
		
		
		//SavingsAccount sa = (SavingsAccount) container.getBean("mySavObj");
		//System.out.println("sa "+sa);
		//c.drive();

		
	}
}
