package carcylinderfactory;

public class Cylinder {
	
	@Override
	public String toString() {
		return "Cylinder [capacity=" + capacity + "]";
	}

	int capacity;
	
	public Cylinder (int cap) { 
		System.out.println("Cylinder ctor");
		capacity =cap ;
	}
	
}
