package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PROJECT_MEMBERS database table.
 * 
 */
@Entity
@Table(name="PROJECT_MEMBERS")
@NamedQuery(name="ProjectMember.findAll", query="SELECT p FROM ProjectMember p")
public class ProjectMember implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="MEM_ID")
	private long memId;

	private BigDecimal age;

	@Column(name="MEMBER_NAME")
	private String memberName;

	//bi-directional many-to-one association to Project
	@ManyToOne
	@JoinColumn(name="EID")
	private Project project;

	public ProjectMember() {
	}

	public long getMemId() {
		return this.memId;
	}

	public void setMemId(long memId) {
		this.memId = memId;
	}

	public BigDecimal getAge() {
		return this.age;
	}

	public void setAge(BigDecimal age) {
		this.age = age;
	}

	public String getMemberName() {
		return this.memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}