package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the RESERVATION database table.
 * 
 */
@Entity
@NamedQuery(name="Reservation.findAll", query="SELECT r FROM Reservation r")
public class Reservation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ticketno;

	@Temporal(TemporalType.DATE)
	private Date bookingdate;

	@Temporal(TemporalType.DATE)
	private Date cancellationdate;

	@Temporal(TemporalType.DATE)
	private Date journeydate;

	
	private Double refund;

	@Temporal(TemporalType.DATE)
	private Date rescheduledate;

	private int seatno;

	private String ticketstatus;

	private int transactionid;

	//bi-directional many-to-one association to AuthorisedTicket
	@OneToMany(mappedBy="reservation", cascade={CascadeType.ALL}, fetch=FetchType.EAGER)
	private Set<AuthorisedTicket> authorisedtickets;

	//bi-directional many-to-one association to BusRoute
	@ManyToOne
	@JoinColumn(name="ROUTENO")
	private BusRoute busroute;

	//bi-directional many-to-one association to Unauthorised
	@OneToMany(mappedBy="reservation", cascade={CascadeType.ALL}, fetch=FetchType.EAGER)
	private Set<Unauthorised> unauthoriseds;

	public Reservation() {
	}

	public int getTicketno() {
		return this.ticketno;
	}

	public void setTicketno(int ticketno) {
		this.ticketno = ticketno;
	}

	public Date getBookingdate() {
		return this.bookingdate;
	}

	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}

	public Date getCancellationdate() {
		return this.cancellationdate;
	}

	public void setCancellationdate(Date cancellationdate) {
		this.cancellationdate = cancellationdate;
	}

	public Date getJourneydate() {
		return this.journeydate;
	}

	public void setJourneydate(Date journeydate) {
		this.journeydate = journeydate;
	}

	public Double getRefund() {
		return this.refund;
	}

	public void setRefund(Double refund) {
		this.refund = refund;
	}

	public Date getRescheduledate() {
		return this.rescheduledate;
	}

	public void setRescheduledate(Date rescheduledate) {
		this.rescheduledate = rescheduledate;
	}

	public int getSeatno() {
		return this.seatno;
	}

	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}

	public String getTicketstatus() {
		return this.ticketstatus;
	}

	public void setTicketstatus(String ticketstatus) {
		this.ticketstatus = ticketstatus;
	}

	public int getTransactionid() {
		return this.transactionid;
	}

	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}

	public Set<AuthorisedTicket> getAuthorisedtickets() {
		return this.authorisedtickets;
	}

	public void setAuthorisedtickets(Set<AuthorisedTicket> authorisedtickets) {
		this.authorisedtickets = authorisedtickets;
	}

	public AuthorisedTicket addAuthorisedticket(AuthorisedTicket authorisedticket) {
		getAuthorisedtickets().add(authorisedticket);
		authorisedticket.setReservation(this);

		return authorisedticket;
	}

	public AuthorisedTicket removeAuthorisedticket(AuthorisedTicket authorisedticket) {
		getAuthorisedtickets().remove(authorisedticket);
		authorisedticket.setReservation(null);

		return authorisedticket;
	}

	public BusRoute getBusroute() {
		return this.busroute;
	}

	public void setBusroute(BusRoute busroute) {
		this.busroute = busroute;
	}

	public Set<Unauthorised> getUnauthoriseds() {
		return this.unauthoriseds;
	}

	public void setUnauthoriseds(Set<Unauthorised> unauthoriseds) {
		this.unauthoriseds = unauthoriseds;
	}

	public Unauthorised addUnauthorised(Unauthorised unauthorised) {
		getUnauthoriseds().add(unauthorised);
		unauthorised.setReservation(this);

		return unauthorised;
	}

	public Unauthorised removeUnauthorised(Unauthorised unauthorised) {
		getUnauthoriseds().remove(unauthorised);
		unauthorised.setReservation(null);

		return unauthorised;
	}

}