package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;


/**
 * The persistent class for the PROJECT database table.
 * 
 */
@Entity
@NamedQuery(name="Project.findAll", query="SELECT p FROM Project p")
public class Project implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long empno;

	private String done;

	private String name;

	private String project;

	private BigDecimal status;

	//bi-directional many-to-one association to ProjectMember
	@OneToMany(mappedBy="project", fetch=FetchType.EAGER)
	private Set<ProjectMember> projectMembers;

	public Project() {
	}

	public long getEmpno() {
		return this.empno;
	}

	public void setEmpno(long empno) {
		this.empno = empno;
	}

	public String getDone() {
		return this.done;
	}

	public void setDone(String done) {
		this.done = done;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProject() {
		return this.project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public BigDecimal getStatus() {
		return this.status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

	public Set<ProjectMember> getProjectMembers() {
		return this.projectMembers;
	}

	public void setProjectMembers(Set<ProjectMember> projectMembers) {
		this.projectMembers = projectMembers;
	}

	public ProjectMember addProjectMember(ProjectMember projectMember) {
		getProjectMembers().add(projectMember);
		projectMember.setProject(this);

		return projectMember;
	}

	public ProjectMember removeProjectMember(ProjectMember projectMember) {
		getProjectMembers().remove(projectMember);
		projectMember.setProject(null);

		return projectMember;
	}

}