package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the AUTHORISEDTICKET database table.
 * 
 */
@Entity
@NamedQuery(name="AuthorisedTicket.findAll", query="SELECT a FROM AuthorisedTicket a")
public class AuthorisedTicket implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int authuserno;

	//bi-directional many-to-one association to Registration
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="REGEMAIL")
	private Registration registration;

	//bi-directional many-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public AuthorisedTicket() {
	}

	public int getAuthuserno() {
		return this.authuserno;
	}

	public void setAuthuserno(int authuserno) {
		this.authuserno = authuserno;
	}

	public Registration getRegistration() {
		return this.registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}