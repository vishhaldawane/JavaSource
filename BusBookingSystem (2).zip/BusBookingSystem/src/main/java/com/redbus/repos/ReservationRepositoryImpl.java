package com.redbus.repos;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.Registration;
import com.redbus.pojos.Reservation;

@Repository
public class ReservationRepositoryImpl implements ReservationRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<Reservation> getAllReservations() {
		Query query = entityManager.createQuery(" from Reservation");
		List<Reservation> allReservations = query.getResultList();
		return allReservations;
	}

	@Override
	public List<Reservation> getSpecificReservations(String startTime) {
		// TODO Auto-generated method stub JPQL  :idea
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(String startTime, String endtime) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(String startTime, String endtime, int routeNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(String startTime, String endtime, int routeNumber,
			Date journeDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(Date journeDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(int routeNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reservation> getSpecificReservations(int routeNumber, Date journeDate) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

		
	
}
