package com.redbus.repos;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusRoute;
import com.redbus.pojos.Registration;

@Repository
public interface RegistrationRepository {
	List<Registration> getAllRegistrations();
}
