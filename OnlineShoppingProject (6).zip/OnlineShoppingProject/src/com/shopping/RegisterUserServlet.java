package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.dao.Register;
import com.shopping.dao.RegisterDAOImpl;

public class RegisterUserServlet extends HttpServlet {
      
	RegisterDAOImpl rdi ;
    
    public RegisterUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		System.out.println("RegisterUserServlet: init() ...");
		rdi = new RegisterDAOImpl();
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		pw.println("doGet()...");
		
		Register regForm = new Register();
		
		//userid, pass, email, age, address
		regForm.setUserId(Long.parseLong(request.getParameter("userid")));
		regForm.setEmail(request.getParameter("email"));
		regForm.setAge(Integer.parseInt(request.getParameter("age")));
		regForm.setAddress(request.getParameter("address"));
		regForm.setPassword(request.getParameter("pass"));
		
		rdi.insertNewUser(regForm);
		
		pw.println("<h3>User registered...</h3>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//user would come here via the method=POST
		PrintWriter pw = response.getWriter();
		pw.println("doPost()...");
		//now divert the user to doGet()
		doGet(request,response);
	}

}
