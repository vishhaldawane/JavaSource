package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

//CRUD MANAGEMENT OF PRODUCT

//Product<--pojo 
//ProductDAO <-- with 5 crud methods 
//ProductDAOImpl <-- 5 crud method implementations

//here ProductServlet is the CHEF <- replaced with DAO
//here ProductServlet is the PRESENTER <-- replaced with JSP
//here ProductServlet is the Controller


public class ProductsServlet extends GenericServlet {
	   
	Connection conn;
	ResultSet rs;
	Statement st;
	
    public ProductsServlet() {
        super();
    	System.out.println("ProductServlet() ctor...");
		
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
        try {
    		
    			System.out.println("Loading the driver...");
    			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
    			System.out.println("Driver loaded...");
    			
    			//DESKTOP-EPTT35F
    			System.out.println("\nTrying to connect to the db");
    									//http://www.google.com:9900/index.jsp
    									//mainpro:organ:thin:@  ip : dbport : instancename
    			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:XE", "scott", "tiger");
    			System.out.println("Connected to the db : "+conn);
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    }

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("ProductServlet: service()");
		//response is aware of clinet side proxy network
		//thread detail 
		
		//it should read the button values and then respond
		
		PrintWriter pw = response.getWriter();
		
		String value = request.getParameter("btn");
		
		/*======================show all ===========================*/
		
		if(value.equalsIgnoreCase("ShowAll"))
		{
			try
			{
				System.out.println("\nTrying to create statement");
				//	java.sql.Statement
				st = conn.createStatement();
				System.out.println("Statement created...");
				
				System.out.println("\nTrying to fire the query....");
				String myQuery = "SELECT PROD.PRODID, DESCRIP,STDPRICE  FROM PRODUCT PROD, PRICE PRC  WHERE PROD.PRODID = PRC.PRODID order by prodid";
				rs = st.executeQuery(myQuery);
				
				System.out.println("Query fired and got the result...");
				
				System.out.println("\nProcess the result...");
			
				request.setAttribute("myresult", rs);
				RequestDispatcher rd = request.getRequestDispatcher("ShowAllProducts.jsp");
				rd.forward(request, response);
				/*
				 * pw.println("<h3>Showing products....</h3>");
				 * 
				 * //rs can be a cursor like variable here //while means like a cursor looping
				 * 
				 * pw.println("<table border=5 cellspacing=10 cellpadding=10>");
				 * 
				 * pw.println("<tr>"); pw.println("<td>PRODUCT ID</td>");
				 * pw.println("<td>PRODUCT DESCRIPTION</td>");
				 * pw.println("<td>STANDARD PRICE</td>"); pw.println("<tr>");
				 * 
				 * while(rs.next()) //rs.next() means goto the next record { //next() means
				 * fetch next row int pno = rs.getInt(1); //first column as int String pnm =
				 * rs.getString(2); //first column as int double prodPrice = rs.getDouble(3);
				 * 
				 * pw.println("<tr>"); pw.println("<td>"+pno+"</td>");
				 * pw.println("<td>"+pnm+"</td>"); pw.println("<td>"+prodPrice +"</td>");
				 * pw.println("<td> Ratings </td>"); pw.println("<td> Review </td>");
				 * 
				 * pw.println("</tr>"); } pw.println("</table>");
				 * pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>"
				 * );
				 */
				
			}
			catch(SQLException e) {
				System.out.println("Problem1 : "+e);
				e.printStackTrace();
			}
			catch(Exception e) {
				System.out.println("Problem2 :     "+e);
				//e.printStackTrace();
			}
		}
		
		/*======================show single ===========================*/
		
		else if(value.equalsIgnoreCase("Show")){
			
			long prodId = Long.parseLong(request.getParameter("prodid"));
			System.out.println("Showing a product of id : "+prodId);
			
			try
			{
				System.out.println("\nTrying to create statement");
				//	java.sql.Statement
				st = conn.createStatement();
				System.out.println("Statement created...");
				
				System.out.println("\nTrying to fire the query....");
				String myQuery = "SELECT PROD.PRODID, DESCRIP,STDPRICE  FROM PRODUCT PROD, PRICE PRC  WHERE PROD.PRODID = PRC.PRODID AND prod.prodid="+prodId;
				rs = st.executeQuery(myQuery);
				
				System.out.println("Query fired and got the result...");
				
				System.out.println("\nProcess the result...");
			
				//PrintWriter pw = response.getWriter(); 
				pw.println("<h3>Showing products....</h3>");
				
				//rs can be a cursor like variable here
				//while means like a cursor looping 
				
				pw.println("<table border=5 cellspacing=10 cellpadding=10>");
				
				pw.println("<tr>");
					pw.println("<td>PRODUCT ID</td>");
					pw.println("<td>PRODUCT DESCRIPTION</td>");
					pw.println("<td>STANDARD PRICE</td>");
				pw.println("<tr>");
				
				if(rs.next()) //rs.next() means goto the next record
				{
					//next() means fetch next row
					int pno = rs.getInt(1); //first column as int
					String pnm = rs.getString(2); //first column as int
					double prodPrice = rs.getDouble(3);
					
					pw.println("<tr>");
						pw.println("<td>"+pno+"</td>");
						pw.println("<td>"+pnm+"</td>");
						pw.println("<td>"+prodPrice +"</td>");
						pw.println("<td> Ratings </td>");
						pw.println("<td> Review </td>");
						
					pw.println("</tr>");
				}
				else {
					pw.println("<tr> Record not found <tr>");
				}
				pw.println("</table>");
				pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
			}
			catch(SQLException e) {
				System.out.println("Problem1 : "+e);
				e.printStackTrace();
			}
			catch(Exception e) {
				System.out.println("Problem2 :     "+e);
				//e.printStackTrace();
			}
		}
		
		/*======================create a product ===========================*/
		
		else if(value.equalsIgnoreCase("Create"))
		{
			
			try {
				//read from html form
				long prodId = Long.parseLong(request.getParameter("prodid"));
				String prodName = request.getParameter("proddesc");
				double prodPrice = Double.parseDouble(request.getParameter("prodprice"));
				
				//read for insert query to database
				PreparedStatement pst1 = conn.prepareStatement("insert into product values (?,?)");
				PreparedStatement pst2 = conn.prepareStatement("insert into price values (?,?,?,null,null)");
				
				pst1.setLong(1, prodId);
				pst1.setString(2, prodName);
				
				pst2.setLong(1, prodId);
				pst2.setDouble(2, prodPrice);
				pst2.setDouble(3, prodPrice);
				
				pst1.executeUpdate();
				pst2.executeUpdate();
				
				
				System.out.println("Creating a product of id : "+prodId+" and "+prodName+" price "+prodPrice);
				pw.println("<h3> Product Created..</h3>");
				pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
				
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/*======================modify a product ===========================*/
		
		else if(value.equalsIgnoreCase("Modify"))
		{
			
			long prodId = Long.parseLong(request.getParameter("prodid"));
			String prodName = request.getParameter("proddesc");
			double prodPrice = Double.parseDouble(request.getParameter("prodprice"));
			
			try {
			
				System.out.println("Modifying a product of id : "+prodId+" and "+prodName+" price "+prodPrice);
				
				//read for insert query to database
				PreparedStatement pst1 = conn.prepareStatement("UPDATE product set descrip=? where prodid=?");
				PreparedStatement pst2 = conn.prepareStatement("UPDATE PRICE   set stdprice=? where prodid=?");
				
				pst1.setString(1, prodName);
				pst1.setLong(2, prodId);
				
				
				pst2.setDouble(1, prodPrice);
				pst2.setLong(2, prodId);
				
			
				pst1.executeUpdate();
				pst2.executeUpdate();
					
				pw.println("<h3> Product Modified ..</h3>");
				pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
				
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			System.out.println("Modifying a product of id : "+prodId+" and "+prodName+" price "+prodPrice);
		}
		
		/*======================Delete a product ===========================*/
		
		else if(value.equalsIgnoreCase("Delete")){
			
			long prodId = Long.parseLong(request.getParameter("prodid"));
			
			try {
			
				System.out.println("Deleting a product of id : "+prodId);
				
				//read for insert query to database
				PreparedStatement pst2 = conn.prepareStatement("delete from PRICE  where prodid=?");
				PreparedStatement pst1 = conn.prepareStatement("delete from product where prodid=?");
				
				pst2.setLong(1, prodId);
				pst1.setLong(1, prodId);
			
			
				pst1.executeUpdate();
				pst2.executeUpdate();
				
				pw.println("<h3> Product Deleted..</h3>");
				pw.println("<a href='http://localhost:8085/OnlineShoppingProject/'>Home</a>");
				
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Deleting a product of id : "+prodId);
			
		}
	}
	
	
	/*======================disconnect/release all resoureces ===========================*/
	public void destroy() {
		try {
			rs.close(); //now close the cursor if not required ahead
			st.close(); // now close the st if dont want ahead
			conn.close(); //close the connection if dont want ahead
			
			System.out.println("Trying to close the connection.");
			conn.close();
			System.out.println("Connection closed...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
