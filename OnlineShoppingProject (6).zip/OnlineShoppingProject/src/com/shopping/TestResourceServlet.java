package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class TestResourceServlet
 */
public class TestResourceServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public TestResourceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String value = request.getParameter("btn");
		System.out.println("Button value : "+value);
		PrintWriter pw = response.getWriter();
		if(value.equalsIgnoreCase("Create")) {
			pw.println("<h3>Servlet should create something</h3>");
		}
		else if(value.equalsIgnoreCase("Modify")) {
			pw.println("<h3>Servlet should modify something</h3>");
		} 
		else if(value.equalsIgnoreCase("Delete")) {
			pw.println("<h3>Servlet should delete something</h3>");
		} 
		else if(value.equalsIgnoreCase("show")) {
			pw.println("<h3>Servlet should show something</h3>");
		} 
		else if(value.equalsIgnoreCase("ShowAll")) {
			pw.println("<h3>Servlet should Show All something</h3>");
		} 
		
		
		
	}

}
