package com.shopping.dao;

import java.util.ArrayList;

public interface RegisterDAO {
	void insertNewUser(Register regDetails);
	
	/*Register selectUser(int id);
	Register selectUser(String email);
	ArrayList<Register> selectUsersByAge(int age);*/
}
