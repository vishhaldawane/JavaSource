package com.shopping.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;

public class LoginDAOImpl implements LoginDAO {

	Connection conn;
	ResultSet rs;
	Statement st;
	
	public LoginDAOImpl() {
		//make the DATABASE connection here
		//instead of LoginServlet 
		try {
    		
			System.out.println("LoginDAOImpl: Loading the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("LoginDAOImpl: Driver loaded...");
			
			//DESKTOP-EPTT35F
			System.out.println("\nLoginDAOImpl: Trying to connect to the db");
									//http://www.google.com:9900/index.jsp
									//mainpro:organ:thin:@  ip : dbport : instancename
			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:XE", "scott", "tiger");
			System.out.println("LoginDAOImpl: Connected to the db : "+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Override
	public Login selectLoginByIdAndPassword(long id, String pass) {
		// run the select query here 
		//instead of LoginServlet
		Login loginDetails = null;
		
		try
		{
			System.out.println("\nLoginDAOImpl: Trying to create statement");
			//	java.sql.Statement
			st = conn.createStatement();
			System.out.println("LoginDAOImpl: Statement created...");
			
			System.out.println("\nLoginDAOImpl: Trying to fire the query....");
			String myQuery = "select * from login where userid="+id+" and password='"+pass+"'";
			rs = st.executeQuery(myQuery);
			
			
			
			if(rs.next()) { //if record is in DB
				loginDetails = new Login(); //blank object
				loginDetails.setLoginId(rs.getInt(1));
				loginDetails.setLoginPassword(rs.getString(2));
			}
			System.out.println("LoginDAOImpl: Query fired and got the result...");
			
			
		}
		catch(SQLException e) {
			System.out.println("LoginDAOImpl: Problem1 : "+e);
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println("LoginDAOImpl: Problem2 :     "+e);
			//e.printStackTrace();
		}
		return loginDetails;
	}

}
