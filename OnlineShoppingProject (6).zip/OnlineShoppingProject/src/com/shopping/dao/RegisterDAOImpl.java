package com.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterDAOImpl implements RegisterDAO {

	Connection conn;
	ResultSet rs;
	Statement st;
	
	public RegisterDAOImpl() {
try {
    		
			System.out.println("RegisterDAOImpl: Loading the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("RegisterDAOImpl: Driver loaded...");
			
			//DESKTOP-EPTT35F
			System.out.println("\nRegisterDAOImpl: Trying to connect to the db");
									//http://www.google.com:9900/index.jsp
									//mainpro:organ:thin:@  ip : dbport : instancename
			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:XE", "scott", "tiger");
			System.out.println("RegisterDAOImpl: Connected to the db : "+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

		
	}
	
	public void insertNewUser(Register regDetails) {
		// TODO Auto-generated method stub
		try {
			//by default the conn is in autocommit mode
			
			conn.setAutoCommit(false); //begin the transaction
			System.out.println("RegisterDAOImpl: transaction started...");
			
			PreparedStatement pst1 = conn.prepareStatement("insert into register values(?,?,?,?)");
			PreparedStatement pst2 = conn.prepareStatement("insert into login values(?,?)");
			System.out.println("RegisterDAOImpl: PreparedStatements made...");
			
			pst1.setLong(1, regDetails.getUserId());
			pst1.setString(2, regDetails.getEmail());
			pst1.setInt(3, regDetails.getAge());
			pst1.setString(4, regDetails.getAddress());
			
			pst2.setLong(1, regDetails.getUserId());
			pst2.setString(2, regDetails.getPassword());
			
			pst1.executeUpdate();
			System.out.println("RegisterDAOImpl: inserted to register...");
			
			pst2.executeUpdate();
			System.out.println("RegisterDAOImpl: inserted to login...");
			
			
			conn.commit(); //save the records if all is fine
			System.out.println("RegisterDAOImpl: Registration committed.....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				conn.rollback();
				System.out.println("RegisterDAOImpl: Registration rollbacked...");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		
	}

}
