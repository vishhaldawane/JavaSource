import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Reservation } from '../reservation';
import { ReservationService } from '../reservation.service';

@Component({
  selector: 'app-view-reservations',
  templateUrl: './view-reservations.component.html',
  styleUrls: ['./view-reservations.component.css']
})
export class ViewReservationsComponent implements OnInit {
  ticketNo: number = 0;

  reservations: Reservation[]; //will have all the records of the DB< -> Dept table
  tempReservations: Reservation[]; // will have the copy of the depts array above

  private subscription: Subscription;
  
  constructor(private resevationService: ReservationService) { }
  // http://localhost:4200/category
  ngOnInit() {
    // subscribe will read the latest category vale
    //u can have a direct call to http
    //TEA is prepared   
    //TEa five star hotel

    //separete Sugar Cube, TeaBags, hot water, boiled milk, 
    //5 people can have diff choice 
    //five Tea against 5 star biryani
    
    this.subscription = this.resevationService.findAllReservations()
    .subscribe((data: Reservation[]) => { // hold the data of DB into this data array
                    this.reservations = data; //copy data array into depts array
                    this.tempReservations = data; //copy it to tempDeps array also
                   // console.log(this.tempDepts);
                    console.log(this.reservations);
                }, (err) => {
                    console.log(err);
                });
    }

    deleteReservation(x: number) //28
    {
      //alert('deleting department '+deptNumber);
      console.log('ticket number searched '+x);
      this.resevationService.deleteReservation(x)
      .subscribe((data: Reservation) => {
        
        if(data == null)  {
          this.tempReservations = this.reservations.filter(d => (d.ticketno != x) ); //10 20 25 30 40 
          this.reservations = this.tempReservations; //only unmatched rows are copied to depts
          console.log('Record deleted '+x);
        }
        /*else {
          console.log(x+' is NOT matched : '+data.deptNumber);
          this.tempDepts = this.depts;
        }*/

    }, (err) => {
        console.log(err);
    });
    }
 
    updateReservationsArray() { //update the "htmlViewAllRecords" if reecord is searched by entering 0 or notning or any number
      if(this.ticketNo == 0)  {
        console.log('its zero : '+this.ticketNo);
        this.tempReservations = this.reservations;
      }
      else {
        console.log('its not zero : '+this.ticketNo);
        this.tempReservations = this.reservations.filter(d => (d.ticketno == this.ticketNo) );
        //console.log('d : '+d.deptNumber+ '  dname : '+d.deptName+ ' dloc : '+d.deptLocation);
        console.log('tempReservations length : '+this.tempReservations.length);
        console.log('reservations     length : '+this.reservations.length);
      }
      
    }
}
