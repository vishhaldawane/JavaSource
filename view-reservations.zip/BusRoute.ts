export class BusRoute {
    routeno: number;
    boarding: string;
    distance: string;
	dropping: string;
	endtime: string;
	fare: DoubleRange;
    starttime: string;
}