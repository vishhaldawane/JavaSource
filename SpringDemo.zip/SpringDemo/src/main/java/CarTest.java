import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import carcylinderfactory.Cylinder;
import carfactory.Engine;
import carshowroom.Car;
import pistonunitfactory.Piston;

class CarShowRoom
{
	//xml would govern the configuration
	
	static Car getACar() {
		Cylinder cyl = new Cylinder(20); //Load Driver
		Piston pist = new Piston(cyl); //Connection
		Engine eng = new Engine(pist); //Statement 
		Car myCar = new Car(eng); //Result rs;
		return myCar;
	}
}
public class CarTest {
	public static void main(String[] args) {
		
		//Car myCar = CarShowRoom.getACar();
		
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		
		//Car  c  = (Car) container.getBean("mycar");
		
		Cylinder c = (Cylinder) container.getBean("mycyl");
		System.out.println(" c "+c);
		//c.drive();

		
	}
}
