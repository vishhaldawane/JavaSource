package com.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class ProductsServlet extends GenericServlet {
	   
	Connection conn;
	ResultSet rs;
	Statement st;
	
    public ProductsServlet() {
        super();
    	System.out.println("ProductServlet() ctor...");
		
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	// TODO Auto-generated method stub
    	super.init(config);
        try {
    		
    			System.out.println("Loading the driver...");
    			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
    			System.out.println("Driver loaded...");
    			
    			//DESKTOP-EPTT35F
    			System.out.println("\nTrying to connect to the db");
    									//http://www.google.com:9900/index.jsp
    									//mainpro:organ:thin:@  ip : dbport : instancename
    			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-EPTT35F:1521:XE", "scott", "tiger");
    			System.out.println("Connected to the db : "+conn);
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    }

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("ProductServlet: service()");
		//response is aware of clinet side proxy network
		//thread detail 
		try
		{
			
			System.out.println("\nTrying to create statement");
			//java.sql.Statement
			st = conn.createStatement();
			System.out.println("Statement created...");
			
			System.out.println("\nTrying to fire the query....");
			String myQuery = "SELECT PROD.PRODID, DESCRIP,STDPRICE  FROM PRODUCT PROD, PRICE PRC  WHERE PROD.PRODID = PRC.PRODID order by prodid";
			rs = st.executeQuery(myQuery);
			
			System.out.println("Query fired and got the result...");
			
			System.out.println("\nProcess the result...");
		
			PrintWriter pw = response.getWriter(); 
			pw.println("<h3>Showing products....</h3>");
			
			//rs can be a cursor like variable here
			//while means like a cursor looping 
			
			pw.println("<table border=5 cellspacing=10 cellpadding=10>");
			
			pw.println("<tr>");
				pw.println("<td>PRODUCT ID</td>");
				pw.println("<td>PRODUCT DESCRIPTION</td>");
				pw.println("<td>STANDARD PRICE</td>");
			pw.println("<tr>");
			
			while(rs.next()) //rs.next() means goto the next record
			{
				//next() means fetch next row
				int pno = rs.getInt(1); //first column as int
				String pnm = rs.getString(2); //first column as int
				double prodPrice = rs.getDouble(3);
				
				pw.println("<tr>");
					pw.println("<td>"+pno+"</td>");
					pw.println("<td>"+pnm+"</td>");
					pw.println("<td>"+prodPrice +"</td>");
					pw.println("<td> Ratings </td>");
					pw.println("<td> Review </td>");
					
				pw.println("</tr>");
			}
			pw.println("</table>");
			
			
			
			
		}
		catch(SQLException e) {
			System.out.println("Problem1 : "+e);
			e.printStackTrace();
		}
		catch(Exception e) {
			System.out.println("Problem2 :     "+e);
			//e.printStackTrace();
		}
		
	
	}
	
	public void destroy() {
		try {
			rs.close(); //now close the cursor if not required ahead
			st.close(); // now close the st if dont want ahead
			conn.close(); //close the connection if dont want ahead
			
			System.out.println("Trying to close the connection.");
			conn.close();
			System.out.println("Connection closed...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
