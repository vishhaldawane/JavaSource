package com.redbus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.redbus.pojos.BusRoute;
import com.redbus.pojos.BusType;
import com.redbus.pojos.Registration;
import com.redbus.pojos.Reservation;
import com.redbus.repos.BusRouteRepository;
import com.redbus.repos.BusTypeRepository;
import com.redbus.repos.RegistrationRepository;
import com.redbus.repos.ReservationRepository;

@SpringBootTest
class BusBookingSystemApplicationTests {

	
	@Autowired
	BusTypeRepository busTypeRepo;
	
	@Autowired
	BusRouteRepository busRouteRepo;
	
	@Autowired
	RegistrationRepository regRepo;
	
	@Autowired
	ReservationRepository reserveRepo;
	
	
	@Test
	void getAllBusTypes() {
		//BUSNUMBER            TYPEOFBUS            BUSSTATUS            FACILITIES
		List<BusType> busTypes = busTypeRepo.getAllBusTypes();
		for (BusType busType : busTypes) {
			System.out.println(busType.getBusnumber()+"\t"+busType.getTypeofbus()+"\t"+busType.getBusstatus()+"\t"+busType.getFacilities());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}
	
	@Test
	void getAllBusRoutes() {
	//	 ROUTENO BUSNUMBER            BOARDING             DROPPING               DISTANCE STARTTIME         ENDTIME               FARE
		List<BusRoute> busRoutes = busRouteRepo.getAllBusRoutes();
		for (BusRoute busRoute : busRoutes) {
			System.out.println(busRoute.getRouteno());
			System.out.println(busRoute.getBustype().getBusnumber());
			System.out.println(busRoute.getBoarding());
			System.out.println(busRoute.getDropping());
			System.out.println(busRoute.getDistance());
			System.out.println(busRoute.getStarttime());
			System.out.println(busRoute.getEndtime());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}

	@Test
	void getAllRegistrations() {
//		REGEMAIL                       PASSWORD             REGNAME         G REGPHONE   DATEOFBIR     WALLET
		List<Registration> allRegs = regRepo.getAllRegistrations();
		
		for (Registration reg: allRegs) {
			System.out.println(reg.getRegemail());
			System.out.println(reg.getPassword());
			System.out.println(reg.getRegname());
			System.out.println(reg.getGender());
			System.out.println(reg.getRegphone());
			System.out.println(reg.getDateofbirth());
			System.out.println(reg.getWallet());
			System.out.println("-----------------");
		}
		System.out.println("contextLoads succedded...");
	}
	
	@Test
	void getAllReservations() {
//		 TICKETNO BOOKINGDA JOURNEYDA     SEATNO    ROUTENO TICKETSTAT CANCELLAT     REFUND RESCHEDUL TRANSACTIONID
		List<Reservation> allReserves = reserveRepo.getAllReservations();
		
		for (Reservation res: allReserves) {
			System.out.println("--------------------------------------");
			System.out.print("\t"+res.getTicketno());
			System.out.print("\t"+res.getBookingdate());
			System.out.print("\t"+res.getJourneydate());
			System.out.print("\t"+res.getSeatno());
			System.out.print("\t"+res.getBusroute().getRouteno());
			System.out.print("\t"+res.getTicketstatus());
			System.out.print("\t"+res.getCancellationdate());
			System.out.print("\t"+res.getRefund());
			System.out.print("\t"+res.getRescheduledate());
			System.out.print("\t"+res.getTransactionid()+"\n");
		}
		System.out.println("contextLoads succedded...");
	}
	
	@Test
	void showSpecificReservations() { //controller would recieve 
		//values from angular form ie boarding point, dropping point dt 
		
		final int BUS_FIXED_SEATS=2;
		int how_many_seats_booked_till_for_this_route=1;

		int routeNumber=1;
		//System.out.println("Enter route number : "+);
		//b.busnumber=1234
		//startTime 
		//end time
		//br.routeno=1 r.journeydate='11-DEC-2020';
		
		String busNumber="1234";

		BusType busType = busTypeRepo.getBusTypes(busNumber);
		System.out.println("Bus Type   : "+busType.getTypeofbus());
		System.out.println("Bus Status : "+busType.getBusstatus());
		System.out.println("Facilities : "+busType.getFacilities());
		System.out.println("Seater     : "+BUS_FIXED_SEATS);
		System.out.println("------------------");
		
		Set<BusRoute> allRoutesOfThisBus = busType.getBusroutes();

		for (BusRoute busRoute : allRoutesOfThisBus) {
			
			if(busRoute.getRouteno() == routeNumber) {
				
				System.out.println("Bus Route : "+busRoute.getRouteno());
				System.out.println("Boarding  : "+busRoute.getBoarding());
				System.out.println("Droping   : "+busRoute.getDropping());
				System.out.println("Distance  : "+busRoute.getDistance());
				System.out.println("StartTime : "+busRoute.getStarttime());
				System.out.println("EndTime   : "+busRoute.getEndtime());
				System.out.println("------------------------");
				
				Set<Reservation> thisRouteReservations =  busRoute.getReservations();
				
				System.out.println("Size of this set : "+thisRouteReservations.size());
				
				if(thisRouteReservations.size()==BUS_FIXED_SEATS) {
					System.out.println("!!! Bus is Full !!!");
				}
				else {
					System.out.println("!!! Seats are available !!!");
				}
				
				for (Reservation  reservation : thisRouteReservations ) {
					System.out.println("-- Reservation Details --");
					System.out.println("Ticket Number : "+reservation.getTicketno());
					System.out.println("Journey Date  : "+reservation.getJourneydate());
					System.out.println("Seat Number   : "+reservation.getSeatno());
					System.out.println("------------------------------");
				}
			}
		}
		
		/*List<BusType> busTypes = busTypeRepo.getAllBusTypes();
		for (BusType busType : busTypes) {
			System.out.println("Bus Number : "+busType.getBusnumber());
		}*/

	}
	
	
	
}
