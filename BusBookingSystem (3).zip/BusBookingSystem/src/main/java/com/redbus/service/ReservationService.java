package com.redbus.service;

import java.util.List;

import com.redbus.pojos.Reservation;

//ReservationRepository <--interface
//ReservationRepositoryImpl <--implementation of the above interface


public interface ReservationService {
	List<Reservation> getAllReservationsService();
}


