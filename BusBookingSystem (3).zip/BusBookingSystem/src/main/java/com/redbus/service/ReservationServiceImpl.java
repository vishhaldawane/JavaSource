package com.redbus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redbus.pojos.Reservation;
import com.redbus.repos.ReservationRepository;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	ReservationRepository reservationRepo;
	
	@Override
	public List<Reservation> getAllReservationsService() {
		try
		{
			System.out.println("Some business logic decision here...1");
			System.out.println("Some business logic decision here...2");
			System.out.println("Some business logic decision here...3");
		
				List<Reservation> allReservations = reservationRepo.getAllReservations();
			System.out.println("Some business logic decision here...5");
			System.out.println("Some business logic decision here...6");
			System.out.println("Some business logic decision here...7");
		
			return allReservations; //send this output to the controller
		}
		catch(RuntimeException e) {
			throw new RuntimeException("Reservation Not found!!!");
		}
	}

}


interface WithdrawService { void withdraw(float x); }
interface DepositService { void deposit(float x); }

class Savings implements WithdrawService, DepositService
{
	public void withdraw(float a) { }
	public void deposit(float a) { }
}

class BankTransferService
{
	static void transferService(WithdrawService s, DepositService t, float amt)
	{
		//object slicing
		s.withdraw(amt);
		//s.deposit(amt);
		t.deposit(amt);
		//t.withdraw(amt);
	}
}
class Bank
{
		void main() {
			Savings sav1 = new Savings(); // Mit - 50000 , 7000 <-- 43000
			Savings sav2 = new Savings(); // Mohan 70000 , <-- 77000
			BankTransferService.transferService(sav1, sav2, 7000);
		}
}




