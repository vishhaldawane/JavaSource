package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the RESERVATION database table.
 * 
 */
@Entity
//@NamedQuery(name="Reservation.findAll", query="SELECT r FROM Reservation r")
public class Reservation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ticketno;
	

	@Temporal(TemporalType.DATE)
	private Date bookingdate;

	@Temporal(TemporalType.DATE)
	private Date cancellationdate;

	@Temporal(TemporalType.DATE)
	private Date journeydate;

	
	private Double refund;

	@Temporal(TemporalType.DATE)
	private Date rescheduledate;

	private int seatno;

	private String ticketstatus;

	private int transactionid;

	
	//@JsonIgnore
	//bi-directional many-to-one association to BusRoute
	@ManyToOne
	@JoinColumn(name="ROUTENO")
	private BusRoute busroute;
		
	//bi-directional many-to-one association to AuthorisedTicket
	//@JsonIgnore
	@OneToMany(mappedBy="reservation", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Set<AuthorisedTicket> authorisedtickets;

	
	//@JsonIgnore
	//bi-directional many-to-one association to Unauthorised
	@OneToMany(mappedBy="reservation", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Set<Unauthorised> unauthoriseds;

	public Reservation() {
		System.out.println("Reservation "+this.ticketno);
	}

	public int getTicketno() {
		return this.ticketno;
	}

	public void setTicketno(int ticketno) {
		this.ticketno = ticketno;
	}

	public Date getBookingdate() {
		return this.bookingdate;
	}

	public void setBookingdate(Date bookingdate) {
		this.bookingdate = bookingdate;
	}

	public Date getCancellationdate() {
		return this.cancellationdate;
	}

	public void setCancellationdate(Date cancellationdate) {
		this.cancellationdate = cancellationdate;
	}

	public Date getJourneydate() {
		return this.journeydate;
	}

	public void setJourneydate(Date journeydate) {
		this.journeydate = journeydate;
	}

	public Double getRefund() {
		return this.refund;
	}

	public void setRefund(Double refund) {
		this.refund = refund;
	}

	public Date getRescheduledate() {
		return this.rescheduledate;
	}

	public void setRescheduledate(Date rescheduledate) {
		this.rescheduledate = rescheduledate;
	}

	public int getSeatno() {
		return this.seatno;
	}

	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}

	public String getTicketstatus() {
		return this.ticketstatus;
	}

	public void setTicketstatus(String ticketstatus) {
		this.ticketstatus = ticketstatus;
	}

	public int getTransactionid() {
		return this.transactionid;
	}

	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}

	@JsonIgnore
	public Set<AuthorisedTicket> getAuthorisedtickets() {
		return this.authorisedtickets;
	}

	public void setAuthorisedtickets(Set<AuthorisedTicket> authorisedtickets) {
		this.authorisedtickets = authorisedtickets;
	}

	
	//@JsonIgnore
	public BusRoute getBusroute() {
		System.out.println("getBusRoute()"+busroute);
		return this.busroute;
	}

	public void setBusroute(BusRoute busroute) {
		System.out.println("setting busRoute");
		this.busroute = busroute;
	}

	@JsonIgnore
	public Set<Unauthorised> getUnauthoriseds() {
		return this.unauthoriseds;
	}

	public void setUnauthoriseds(Set<Unauthorised> unauthoriseds) {
		this.unauthoriseds = unauthoriseds;
	}

	@Override
	public String toString() {
		return "Reservation [ticketno=" + ticketno + ", busroute=" + busroute+ "]";
	}

	

}