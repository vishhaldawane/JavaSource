package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;

/**
 * The persistent class for the BUSROUTE database table.
 * 
 */
@Entity
@NamedQuery(name = "BusRoute.findAll", query = "SELECT b FROM BusRoute b")
public class BusRoute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.AUTO)
	private int routeno;

	private String boarding;

	private int distance;

	private String dropping;

	private String endtime;

	private double fare;

	private String starttime;

	// bi-directional many-to-one association to BusType
	@ManyToOne
	@JoinColumn(name = "BUSNUMBER")
	private BusType bustype;

	
	
	@JsonIgnore
	// bi-directional many-to-one association to Reservation
	@OneToMany(mappedBy = "busroute", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private Set<Reservation> reservations;

	public BusRoute() {
	}

	public int getRouteno() {
		System.out.println("getRouteno() called...");
		return this.routeno;
	}

	public void setRouteno(int routeno) {
		this.routeno = routeno;
	}

	public String getBoarding() {
		return this.boarding;
	}

	public void setBoarding(String boarding) {
		this.boarding = boarding;
	}

	public int getDistance() {
		return this.distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public String getDropping() {
		return this.dropping;
	}

	public void setDropping(String dropping) {
		this.dropping = dropping;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public double getFare() {
		return this.fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public String getStarttime() {
		return this.starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	@JsonIgnore
	public BusType getBustype() {
		return this.bustype;
	}

	public void setBustype(BusType bustype) {
		this.bustype = bustype;
	}

	@JsonIgnore
	public Set<Reservation> getReservations() {
		return this.reservations;
	}

	public void setReservations(Set<Reservation> reservations) {
		this.reservations = reservations;
	}

	@Override
	public String toString() {
		return "BusRoute [routeno=" + routeno + "]";
	}

}