package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the UNAUTHORISED database table.
 * 
 */
@Entity
@NamedQuery(name="Unauthorised.findAll", query="SELECT u FROM Unauthorised u")
public class Unauthorised implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int unauserno;

	private String email;

	private String phone;

	//bi-directional many-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public Unauthorised() {
	}

	public int getUnauserno() {
		return this.unauserno;
	}

	public void setUnauserno(int unauserno) {
		this.unauserno = unauserno;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@JsonIgnore
	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}