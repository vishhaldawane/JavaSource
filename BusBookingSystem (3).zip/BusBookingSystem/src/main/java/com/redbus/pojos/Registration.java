package com.redbus.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the REGISTRATION database table.
 * 
 */
@Entity
@NamedQuery(name="Registration.findAll", query="SELECT r FROM Registration r")
public class Registration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String regemail;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	private String gender;

	private String password;

	private String regname;

	private String regphone;

	private Double wallet;

	//bi-directional many-to-one association to AuthorisedTicket
	@OneToMany(mappedBy="registration", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Set<AuthorisedTicket> authorisedtickets;

	public Registration() {
	}

	public String getRegemail() {
		return this.regemail;
	}

	public void setRegemail(String regemail) {
		this.regemail = regemail;
	}

	public Date getDateofbirth() {
		return this.dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRegname() {
		return this.regname;
	}

	public void setRegname(String regname) {
		this.regname = regname;
	}

	public String getRegphone() {
		return this.regphone;
	}

	public void setRegphone(String regphone) {
		this.regphone = regphone;
	}

	public Double getWallet() {
		return this.wallet;
	}

	public void setWallet(Double wallet) {
		this.wallet = wallet;
	}

	public Set<AuthorisedTicket> getAuthorisedtickets() {
		return this.authorisedtickets;
	}

	public void setAuthorisedtickets(Set<AuthorisedTicket> authorisedtickets) {
		this.authorisedtickets = authorisedtickets;
	}

	

}