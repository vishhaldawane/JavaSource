package com.redbus.repos;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.Registration;
import com.redbus.pojos.Reservation;

@Repository
public class ReservationRepositoryImpl implements ReservationRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<Reservation> getAllReservations() {
		Query query = entityManager.createQuery(" from Reservation");
		List<Reservation> allReservations = query.getResultList();
		return allReservations;
	}

	
	
	@Transactional
                        //getSpecificReservations(String boarding, String dropping, int routeNumber,  Date journeyDate);
    public List<Object[]> getSpecificReservations(String boarding, String dropping, int routeNumber,  Date journeyDate) {
        // TODO Auto-generated method stub
        Query query=entityManager.createNativeQuery("select br.boarding,"
        		+ "br.dropping,"
        		+ "br.routeno,"
        		+ "r.journeydate "
        		+ "from "
        		+ "bus_route br,"
        		+ "reservation r where "
        		+ "br.routeno=r.routeno       and "
        		+ "br.routeno="+routeNumber+" and "
        		+ "br.boarding="+"'"+boarding+"'   and "
        		+ "br.dropping="+"'"+dropping+"'   and " 
        		+ "to_char(r.journeydate,'dd-Mon-yyyy')="+"'to_char("+journeyDate+",'dd-Mon-yyyy')'");
        
        List<Object[]> res = query.getResultList();
        
        
        
        return res;
    }
	
    
    

		
	
}
