package com.redbus.repos;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusRoute;
import com.redbus.pojos.Reservation;

@Repository
public interface ReservationRepository {
	List<Reservation> getAllReservations();
	
	/*
	//journey date 
	List<Reservation> getSpecificReservations(String startTime);
	List<Reservation> getSpecificReservations(String startTime, String endtime);
	List<Reservation> getSpecificReservations(String startTime, String endtime, int routeNumber);
	List<Reservation> getSpecificReservations(String startTime, String endtime, int routeNumber, Date journeDate );
	List<Reservation> getSpecificReservations(Date journeDate );
	List<Reservation> getSpecificReservations(int routeNumber );
	List<Reservation> getSpecificReservations(int routeNumber, Date journeDate );
	
	*/
    public List<Object[]> getSpecificReservations(String boarding, String dropping, int routeNumber,  Date journeyDate);
	
}
