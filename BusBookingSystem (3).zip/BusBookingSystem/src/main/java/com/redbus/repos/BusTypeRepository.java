package com.redbus.repos;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusType;

@Repository
public interface BusTypeRepository {
	List<BusType> getAllBusTypes();
	BusType getBusTypes(String busNumber);
}
