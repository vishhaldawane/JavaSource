package com.redbus.repos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.redbus.pojos.BusType;

@Repository
public class BusTypeRespositoryImpl implements BusTypeRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public List<BusType> getAllBusTypes() {
			Query query = entityManager.createQuery(" from BusType");
			List<BusType> busTypes = query.getResultList();
		return busTypes;
	}

	@Transactional
	public BusType getBusTypes(String busNumber) {
		BusType busType =  entityManager.find(BusType.class,busNumber);
		return busType;
	}

}
