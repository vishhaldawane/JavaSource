package com.redbus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.redbus.pojos.Reservation;
import com.redbus.service.ReservationService;

//		apache tomcat here										ng serve is running on 4200
//			    Socket											   Socket				
//spring http://ip:8085/OurSpringControllerHereRunnig <--> http://ip:4200/ 
@RestController														//			|
@CrossOrigin														//  http.get('ip:8085/getAllReservations')
public class BusController {										// a button click to call above url
																								
	@Autowired
	ReservationService reservationService;
	
	//@JsonIgnore
	@GetMapping(path="/getAllReservations")
	List<Reservation> getAllReservations() {
		System.out.println("---> inside getAllReservations");
		List<Reservation>  results = reservationService.getAllReservationsService();
		for (Reservation reservation : results) {
			System.out.println("=>Reservation : "+reservation);
		}
		return results;
	}
	
}
