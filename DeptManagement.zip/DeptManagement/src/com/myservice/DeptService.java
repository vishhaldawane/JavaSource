package com.myservice;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// http://ip:port/DeptManagement/DeptService/rest/depts

@Path("/DeptService")
public class DeptService {
	
	DeptDao dd = new DeptDao();

	@GET
	@Path("/depts")
	@Produces(MediaType.APPLICATION_XML)
	public List<Dept> getDepts() {
		
		return dd.getAllDepts();
	}
}
