package com.bank;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dept20")
public class Department {
	
	
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Department() ctor...");
	}

	public Department(int departmentNumber, String departmentName, String deparmentLocation) {
		super();
		System.out.println("Department(int,String,String) ctor...");
		this.departmentNumber = departmentNumber;
		this.departmentName = departmentName;
		this.deparmentLocation = deparmentLocation;
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDeparmentLocation() {
		return deparmentLocation;
	}

	public void setDeparmentLocation(String deparmentLocation) {
		this.deparmentLocation = deparmentLocation;
	}

	@Id
	@Column(name="deptno")
	private int departmentNumber;
	
	@Column(name="dname", length = 15)
	private String departmentName;
	
	@Column(name="loc", length = 15)
	private String deparmentLocation;
	
	
	
}
