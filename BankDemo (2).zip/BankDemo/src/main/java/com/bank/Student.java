package com.bank;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity //table would be as per teh class name
public class Student {
	
	@Id // <-- for the primary key as rollNumber below
	int rollNumber;
	
	@Column(length=20)
	String name;
	float marks;
	
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	
}
