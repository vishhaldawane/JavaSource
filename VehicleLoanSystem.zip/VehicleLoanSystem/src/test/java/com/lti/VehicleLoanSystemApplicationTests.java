package com.lti;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.lti.repo.VehicleRepository;

@SpringBootTest
class VehicleLoanSystemApplicationTests {

	
	@Autowired
	VehicleRepository vehiRepo;
	
	@Test
	void contextLoads() {
		Register reg = vehiRepo.getRegistration(104);
		System.out.println("Reg is : "+reg.getEmail());
		
		Application application = vehiRepo.getSingleApplication(204);
		System.out.println("MyApp id : "+application.getAppid());
		
		CarDetail carDetail = vehiRepo.getCarDetail(2);
		System.out.println("Loan applied for : "+carDetail.getModel());
		
//				fk	      fk
// LOANID      VEHID      APPID     AMTREQ     TENURE        ROI STATUS
// 1004          3        204      99999         84        5.5 Approved

		LoanDetail loanDetail = new LoanDetail();
		loanDetail.setAmtreq(99999l);
		loanDetail.setTenure(54);
		loanDetail.setRoi(5.5);
		loanDetail.setStatus("Unknown");
		
		loanDetail.setCarDetail(carDetail);
		
		loanDetail.setApplication(application);
		//application.setLoanDetail(loanDetail);
		
		vehiRepo.createNewLoan(loanDetail);
		System.out.println("Loan Detail inserted...");
		
		/*Set<Application> myApps = reg.getApplications();
		for (Application application : myApps) {
			System.out.println("MyApp id : "+application.getAppid());
		}*/
		
	}
	
	@Test
	void contextLoads2() {
		
		List<LoanDetail> allLoans = vehiRepo.getAllLoans();
		for (LoanDetail loanDetail : allLoans) {
			System.out.println("Loan Id : "+loanDetail.getLoanid());
			//System.out.println("Loan Id : "+loanDetail.getCarDetail());
			System.out.println("Amt Req : "+loanDetail.getAmtreq());
			System.out.println("Tenure  : "+loanDetail.getTenure());
			System.out.println("ROI     : "+loanDetail.getRoi());
			System.out.println("Status  : "+loanDetail.getStatus());
		}
	}

}
