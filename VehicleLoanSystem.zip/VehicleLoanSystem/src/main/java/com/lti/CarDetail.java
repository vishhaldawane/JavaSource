package com.lti;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the CAR_DETAILS database table.
 * 
 */
@Entity
@Table(name="CAR_DETAILS")
@NamedQuery(name="CarDetail.findAll", query="SELECT c FROM CarDetail c")
public class CarDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int vehid;

	private String category;

	private String color;

	private String company;

	private Long exprice;

	private String model;

	private String variant;

	//bi-directional many-to-one association to LoanDetail
	@OneToMany(mappedBy="carDetail", fetch=FetchType.EAGER)
	private Set<LoanDetail> loanDetails;

	public CarDetail() {
	}

	public int getVehid() {
		return this.vehid;
	}

	public void setVehid(int vehid) {
		this.vehid = vehid;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Long getExprice() {
		return this.exprice;
	}

	public void setExprice(Long exprice) {
		this.exprice = exprice;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getVariant() {
		return this.variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public Set<LoanDetail> getLoanDetails() {
		return this.loanDetails;
	}

	public void setLoanDetails(Set<LoanDetail> loanDetails) {
		this.loanDetails = loanDetails;
	}

	public LoanDetail addLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().add(loanDetail);
		loanDetail.setCarDetail(this);

		return loanDetail;
	}

	public LoanDetail removeLoanDetail(LoanDetail loanDetail) {
		getLoanDetails().remove(loanDetail);
		loanDetail.setCarDetail(null);

		return loanDetail;
	}

}