package com.lti;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the EMI_SCHEDULE database table.
 * 
 */
@Entity
@Table(name="EMI_SCHEDULE")
@NamedQuery(name="EmiSchedule.findAll", query="SELECT e FROM EmiSchedule e")
public class EmiSchedule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int loanid;

	@Temporal(TemporalType.TIMESTAMP)
	private Date appldate;

	private Long emi;

	private String emisch;

	private Long loansan;

	@Temporal(TemporalType.TIMESTAMP)
	private Date sancdate;

	private Long totalloan;

	//bi-directional one-to-one association to LoanDetail
	@OneToOne
	@JoinColumn(name="LOANID")
	private LoanDetail loanDetail;

	public EmiSchedule() {
	}

	public int getLoanid() {
		return this.loanid;
	}

	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}

	public Date getAppldate() {
		return this.appldate;
	}

	public void setAppldate(Date appldate) {
		this.appldate = appldate;
	}

	public Long getEmi() {
		return this.emi;
	}

	public void setEmi(Long emi) {
		this.emi = emi;
	}

	public String getEmisch() {
		return this.emisch;
	}

	public void setEmisch(String emisch) {
		this.emisch = emisch;
	}

	public Long getLoansan() {
		return this.loansan;
	}

	public void setLoansan(Long loansan) {
		this.loansan = loansan;
	}

	public Date getSancdate() {
		return this.sancdate;
	}

	public void setSancdate(Date sancdate) {
		this.sancdate = sancdate;
	}

	public Long getTotalloan() {
		return this.totalloan;
	}

	public void setTotalloan(Long totalloan) {
		this.totalloan = totalloan;
	}

	public LoanDetail getLoanDetail() {
		return this.loanDetail;
	}

	public void setLoanDetail(LoanDetail loanDetail) {
		this.loanDetail = loanDetail;
	}

}