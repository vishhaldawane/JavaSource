package com.lti;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the "REGISTER" database table.
 * 
 */
@Entity
@Table(name="REGISTER")
@NamedQuery(name="Register.findAll", query="SELECT r FROM Register r")
public class Register implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int custid;

	private String altermobile;

	private String city;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dob;

	private String email;

	private String fname;

	private String gender;

	private String lname;

	private String mname;

	private String mobile;

	private String pan;

	private String password;

	private Long pincode;

	@Column(name="STATE")
	private String state;

	//bi-directional many-to-one association to Application
	@OneToMany(mappedBy="register", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<Application> applications;

	public Register() {
	}

	public int getCustid() {
		return this.custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getAltermobile() {
		return this.altermobile;
	}

	public void setAltermobile(String altermobile) {
		this.altermobile = altermobile;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPan() {
		return this.pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPincode() {
		return this.pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set<Application> getApplications() {
		return this.applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}

	public Application addApplication(Application application) {
		getApplications().add(application);
		application.setRegister(this);

		return application;
	}

	public Application removeApplication(Application application) {
		getApplications().remove(application);
		application.setRegister(null);

		return application;
	}

}