package com.lti;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the LOAN_DETAILS database table.
 * 
 */
@Entity
@Table(name="LOAN_DETAILS")
@NamedQuery(name="LoanDetail.findAll", query="SELECT l FROM LoanDetail l")
public class LoanDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int loanid; private Long amtreq; 	private Double roi; 	private String status; 	private int tenure;
	//bi-directional one-to-one association to EmiSchedule

	@OneToOne(mappedBy="loanDetail")
	private EmiSchedule emiSchedule;

	//bi-directional many-to-one association to CarDetail
	@ManyToOne
	@JoinColumn(name="VEHID")
	private CarDetail carDetail;

	//bi-directional one-to-one association to Application
	//@JsonIgnore
	@OneToOne//(mappedBy="loanDetail")
	@JoinColumn(name="APPID", unique = true )
	private Application application;
	
	/*
	  				fk		 fk
	 *loanid						   amtreq 	  tenure  	    roi status
	  LOANID      VEHID      APPID     AMTREQ     TENURE        ROI STATUS
---------- ---------- ---------- ---------- ---------- ---------- ----------
      1001          1        201     700000         84          8 approved
      1002          2        202    1500000         84        7.5 approved
      1003          3        203     900000         84          8 approved
	  
	 */
	public LoanDetail() {
	}

	public int getLoanid() {
		return this.loanid;
	}

	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}

	public Long getAmtreq() {
		return this.amtreq;
	}

	public void setAmtreq(Long amtreq) {
		this.amtreq = amtreq;
	}

	public Double getRoi() {
		return this.roi;
	}

	public void setRoi(Double roi) {
		this.roi = roi;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTenure() {
		return this.tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public EmiSchedule getEmiSchedule() {
		return this.emiSchedule;
	}

	public void setEmiSchedule(EmiSchedule emiSchedule) {
		this.emiSchedule = emiSchedule;
	}

	

	public CarDetail getCarDetail() {
		return this.carDetail;
	}

	public void setCarDetail(CarDetail carDetail) {
		this.carDetail = carDetail;
	}

	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}