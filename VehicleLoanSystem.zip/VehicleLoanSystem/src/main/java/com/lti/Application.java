package com.lti;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the APPLICATION database table.
 * 
 */
@Entity
@NamedQuery(name="Application.findAll", query="SELECT a FROM Application a")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int appid;

	private String aadhaar;

	private String accno;

	private String acctype;

	private String address;

	private long annualinc;

	private String branch;

	private long existingemi;

	private String ifsc;

	private String licence;

	private String occupation;

	//bi-directional many-to-one association to Register
	@ManyToOne
	@JoinColumn(name="CUSTID")
	private Register register;

	//bi-directional one-to-one association to LoanDetail
	@OneToOne(mappedBy ="application")
	//@JoinColumn(name="APPID", referencedColumnName="APP_ID")
	private LoanDetail loanDetail;
	
	public Application() {
	}

	public int getAppid() {
		return this.appid;
	}

	public void setAppid(int appid) {
		this.appid = appid;
	}

	public String getAadhaar() {
		return this.aadhaar;
	}

	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}

	public String getAccno() {
		return this.accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public String getAcctype() {
		return this.acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getAnnualinc() {
		return this.annualinc;
	}

	public void setAnnualinc(long annualinc) {
		this.annualinc = annualinc;
	}

	public String getBranch() {
		return this.branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getExistingemi() {
		return this.existingemi;
	}

	public void setExistingemi(long existingemi) {
		this.existingemi = existingemi;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getLicence() {
		return this.licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Register getRegister() {
		return this.register;
	}

	public void setRegister(Register register) {
		this.register = register;
	}


	public LoanDetail getLoanDetail() {
		return this.loanDetail;
	}

	public void setLoanDetail(LoanDetail loanDetail) {
		this.loanDetail = loanDetail;
	}

}