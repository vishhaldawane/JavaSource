package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleLoanSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleLoanSystemApplication.class, args);
		System.out.println("Started the Application");
	}

}
