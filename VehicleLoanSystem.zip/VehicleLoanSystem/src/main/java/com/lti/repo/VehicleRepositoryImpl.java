package com.lti.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.Application;
import com.lti.CarDetail;
import com.lti.LoanDetail;
import com.lti.Register;


@Repository
public class VehicleRepositoryImpl  implements VehicleRepository 
{

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Transactional
	public Register getRegistration(int regId) {
		return entityManager.find(Register.class, regId);
	}
	
	@Transactional
	public List<LoanDetail> getAllLoans() {
		
		Query query = entityManager.createQuery(" from LoanDetail");
		List<LoanDetail> allLoans = query.getResultList();
		return allLoans ;
	}
	
	@Transactional
	public Application getSingleApplication(int appId) {
		return entityManager.find(Application.class, appId);
	}

	@Transactional
	public CarDetail getCarDetail(int vehId) {
		return entityManager.find(CarDetail.class, vehId);
	}

	@Transactional
	public void createNewLoan(LoanDetail loanDetail) {
		//Register reg = getRegistration(104);
		entityManager.persist(loanDetail);
		
	}

}
