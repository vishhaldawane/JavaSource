package com.lti.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.Application;
import com.lti.CarDetail;
import com.lti.LoanDetail;
import com.lti.Register;

@Repository
public interface VehicleRepository {

		Register getRegistration(int regId);
		Application getSingleApplication(int appId);
		CarDetail getCarDetail(int vehId);
		public void createNewLoan(LoanDetail loanDetail);
		public List<LoanDetail> getAllLoans();

}
