import { Component, OnInit } from '@angular/core';
import { CarPartsService } from '../carparts.service';

@Component({
  selector: 'app-view-carparts',
  template: `
    <button (click)="viewCarParts()">View CarParts</button>
    <table *ngIf="data" border="1">
      <tr><th>Part No</th><th>Part Name</th><th>Car Model</th><th>Price</th><th>Quantity</th></tr>
      <tr *ngFor="let cp of data">
        <td>{{cp.partNo}}</td>
        <td>{{cp.name}}</td>
        <td>{{cp.carModel}}</td>
        <td>{{cp.price}}</td>
        <td>{{cp.quantity}}</td>
      </tr>
    </table>
  `,
  styles: [
  ]
})
export class ViewCarpartsComponent {

  data: any;

  constructor(private service: CarPartsService) { }

  viewCarParts() {
    this.service.fetchCarParts().subscribe(data => {
      //alert(JSON.stringify(data));
      this.data = data;
    })
  }
}
