import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CarPart } from './carpart';

@Injectable({
  providedIn: 'root'
})
export class CarPartsService {

  constructor(private http: HttpClient) { }

  fetchCarParts() {
    let url = 'http://localhost:8181/spring-mvc/fetchCarParts.api';
    return this.http.get(url);
  }

  addCarPart(carPart: CarPart) {
    let url = 'http://localhost:8181/spring-mvc/addCarPart.api';
    return this.http.post(url, carPart);
  }


}
