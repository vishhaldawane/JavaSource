export class CarPart {
    partNo: number;
    name: string;
    carModel: string;
    price: number;
    quantity: number;
}