package com.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "Employee1")
public class Employee {

	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=15) 
	private String name;
	
	//default lazy behavior : eager
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cubicle_id_fk") //foreign key column is not a table's data member
	private Cubicle assignedCubicle;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Cubicle getAssignedCubicle() {
		return assignedCubicle;
	}

	public void setAssignedCubicle(Cubicle assignedCubicle) {
		this.assignedCubicle = assignedCubicle;
	}
	
	
}
