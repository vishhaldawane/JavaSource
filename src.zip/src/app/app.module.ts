import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AccountSummaryModule } from './account-summary/account-summary.module';
import { FundTransferModule } from './fund-transfer/fund-transfer.module';
import { CurrencyConveterService } from './currency-conveter.service';
import { HomeComponent } from './home/home.component';
import { SettingsComponent } from './settings/settings.component';
import { SettingsContactComponent } from './settings-contact/settings-contact.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

import {HttpClientModule } from '@angular/common/http';
import { ViewAllDepartmentComponent } from './department/view-all-department/view-all-department.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    SettingsComponent,
    SettingsContactComponent,
    SettingsProfileComponent,
    PageNotFoundComponent,
    ViewAllDepartmentComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    AccountSummaryModule,
    FundTransferModule,
    HttpClientModule
  ],
  providers: [ CurrencyConveterService ],
  bootstrap: [AppComponent]
})
export class AppModule {


 }
