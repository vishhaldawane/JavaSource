import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  company = "Larsen and Toubro Infotech Limited";

  userNames = ["Rajesh","Abhishikt","Mythili","Paris"];
  isloggedIn=true;
  birthDate = new Date();

  myClickFunction(event) {
    alert('My Click Function invoked...');
    console.log(event);
  }

  userChanged(event) {
    alert('User is changed...');
    console.log(event);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
