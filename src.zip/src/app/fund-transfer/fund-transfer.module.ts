import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { ViewAllPayeesComponent } from './view-all-payees/view-all-payees.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';



@NgModule({
  declarations: [AddPayeeComponent, ViewPayeeComponent, ViewAllPayeesComponent, DeletePayeeComponent, FundTransferComponent],
  imports: [
    CommonModule
  ],
  exports: [AddPayeeComponent, ViewPayeeComponent, ViewAllPayeesComponent, DeletePayeeComponent, FundTransferComponent],
})
export class FundTransferModule { }
