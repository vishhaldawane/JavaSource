import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-payee',
  templateUrl: './view-payee.component.html',
  styleUrls: ['./view-payee.component.css']
})
export class ViewPayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
