import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-payees',
  templateUrl: './view-all-payees.component.html',
  styleUrls: ['./view-all-payees.component.css']
})
export class ViewAllPayeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
