import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { SettingsContactComponent } from './settings-contact/settings-contact.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';
import { SettingsComponent } from './settings/settings.component';

//ng g module app-routing <--- for those who have not got the app-routing.module.ts


const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    
    { path: 'home', component: HomeComponent },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },

    { path: 'settings', component: SettingsComponent,
        children: [
            { path: '', redirectTo: 'profile', pathMatch: 'full' },
            { path: 'profile', component: SettingsProfileComponent },
            { path: 'contact', component: SettingsContactComponent },
            { path: '**', redirectTo: 'profile', pathMatch:'full' },
        ]
    },
    { path: '**', component: PageNotFoundComponent }
];
/*
http://localhost:4200/home
http://localhost:4200/home/junk
http://localhost:4200/login
http://localhost:4200/login/junk
http://localhost:4200/register
http://localhost:4200/register/junk
http://localhost:4200/settings/junk
http://localhost:4200/settings/profile
http://localhost:4200/settings/contact
http://localhost:4200/settings/contacting
*/


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
