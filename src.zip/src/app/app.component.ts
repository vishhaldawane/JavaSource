import { Component } from '@angular/core';
import { CurrencyConveterService } from './currency-conveter.service';

import { HttpClient } from '@angular/common/http'; //1

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent { 
  
  constructor(private ccs: CurrencyConveterService, private myhttp:HttpClient) {
    //this.css = new CurrencyConveterService();
    this.ccs.convertCurrency('converting INR to USD');
  }
  ngOnInit() { //3
   //this.myhttp.get('http://localhost:8080/MyAirline/allFlights')

   /*
    this.myhttp.get('http://jsonplaceholder.typicode.com/users').
     subscribe((data)=>console.log(data);
    */

     this.myhttp.get('http://jsonplaceholder.typicode.com/users').
     subscribe((dataFromNet)=>this.displayData(dataFromNet));
  }

  thisPageGlobalData; //global data variable

  displayData(dataFromNet) {
    this.thisPageGlobalData = dataFromNet; //global data variable
     //initialize this global mydata with data
  }

}
