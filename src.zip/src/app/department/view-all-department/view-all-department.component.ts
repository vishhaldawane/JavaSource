import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { Department } from '../department';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-view-all-department',
  templateUrl: './view-all-department.component.html',
  styleUrls: ['./view-all-department.component.css']
})
export class ViewAllDepartmentComponent implements OnInit {
  deptNo: number = 0;

  depts: Department[];
  tempDepts: Department[];

  private subscription: Subscription;
  
  constructor(private deptService: DepartmentService) { }
  // http://localhost:4200/category
  ngOnInit() {
    // subscribe will read the latest category vale
    this.subscription = this.deptService.findAllDepartments()
    .subscribe((data: Department[]) => {
                    this.depts = data;
                    this.tempDepts = data;
                   // console.log(this.tempDepts);
                   // console.log(this.depts);
                }, (err) => {
                    console.log(err);
                });
    }

    deleteDepartment(x: number)
    {
      //alert('deleting department '+deptNumber);
      console.log('dept number searched '+x);
      this.deptService.deleteDeparment(x)
      .subscribe((data: Department) => {
        
        if(data == null)  {
          //console.log(x+' is not matched : '+data.deptNumber);
          this.tempDepts = this.depts.filter(d => (d.deptNumber != x) );
          this.depts = this.tempDepts;
          console.log('Record deleted '+x);
        }
        /*else {
          console.log(x+' is NOT matched : '+data.deptNumber);
          this.tempDepts = this.depts;
        }*/

    }, (err) => {
        console.log(err);
    });
    }

    updateDepartmentArray() {
      if(this.deptNo == 0)  {
        console.log('its zero : '+this.deptNo);
        this.tempDepts = this.depts;
      }
      else {
        console.log('its not zero : '+this.deptNo);
        this.tempDepts = this.depts.filter(d => (d.deptNumber == this.deptNo) );
        //console.log('d : '+d.deptNumber+ '  dname : '+d.deptName+ ' dloc : '+d.deptLocation);
        console.log('tempDepts length : '+this.tempDepts.length);
        console.log('depts length : '+this.depts.length);
        
      }
      
    }
}
