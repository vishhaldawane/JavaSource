import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-department',
  templateUrl: './delete-department.component.html',
  styleUrls: ['./delete-department.component.css']
})
export class DeleteDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
