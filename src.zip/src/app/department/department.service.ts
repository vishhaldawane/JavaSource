import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department } from './department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  baseUrl: string = 'http://localhost:8085/DeptManagement/rest/DepartmentService/';
  constructor(private myhttp:HttpClient) { }

  findDepartment(deptNumber: number): Observable<Department> 
  {
    return this.myhttp.get<Department>(this.baseUrl + "getDept/" + deptNumber);
  }

  findAllDepartments() :Observable<Department[]>
  {
    return this.myhttp.get<Department[]>(this.baseUrl+"getDepts/");
  }

  addNewDeparment(newDept: Department): Observable<Department>
  {
    return this.myhttp.post<Department>(this.baseUrl+"addDept/",newDept);
  }

  modifyDeparment(existingDept: Department): Observable<Department>
  {
    return this.myhttp.put<Department>(this.baseUrl + "updateDept/", existingDept);
  }
  
  deleteDeparment(deptNumber: number) : Observable<Department>
  {
    return this.myhttp.delete<Department>(this.baseUrl + "deleteDept/" + deptNumber);
                    
  }

}
