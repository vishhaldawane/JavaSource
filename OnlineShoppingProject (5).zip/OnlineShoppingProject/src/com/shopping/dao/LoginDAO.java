package com.shopping.dao;

public interface LoginDAO {
	Login selectLoginByIdAndPassword(long id, String pass);
}
