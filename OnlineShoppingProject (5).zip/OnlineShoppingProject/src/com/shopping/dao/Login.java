package com.shopping.dao;

//pojo as per the Login table mapping

public class Login {
	public Login() {
		System.out.println("Login() pojo created....");
	}
	
	public long getLoginId() {
		System.out.println("getLoginId()");
		return loginId;
	}
	public void setLoginId(long loginId) {
		System.out.println("setLoginId(long)");
		this.loginId = loginId;
	}
	
	public String getLoginPassword() {
		System.out.println("getLoginPassword()");
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		System.out.println("setLoginPassword(String)");
		this.loginPassword = loginPassword;
	}
	private long loginId;
	private String loginPassword;
	
	
	
}
