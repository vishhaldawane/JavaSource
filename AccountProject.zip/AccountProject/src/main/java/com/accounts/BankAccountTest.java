package com.accounts;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory; //SessionFactory
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.Test;

public class BankAccountTest {
	
	@Test
	public void testAddBankAccount() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("Hibernate-JPA"); //META-INF/persistence.xml
		
		System.out.println("EntityManagerFactory created : "+entityManagerFactory );
		
		EntityManager entityManager = entityManagerFactory.createEntityManager(); 		//nothing but the Session
		System.out.println("EntityManager : "+entityManager);
		
		EntityTransaction tx 		= entityManager.getTransaction();
		System.out.println("EntityTransaction : "+tx);
		
		tx.begin(); 		
		BankAccount ba1 = new BankAccount();
		ba1.setAccountHolder("Dinesh");
		ba1.setAccountBalance(8820553464.0);
		
		BankAccount ba2 = new BankAccount();
		ba2.setAccountHolder("Dinesh");
		ba2.setAccountBalance(8820553464.0);
		
		BankAccount ba3 = new BankAccount();
		ba3.setAccountHolder("Deven");
		ba3.setAccountBalance(7720553464.0);
		
			entityManager.persist(ba1); //  session.save(cd);
			entityManager.persist(ba2); //  session.save(cd);
			entityManager.persist(ba3); //  session.save(cd);
			
			System.out.println("Persisted...");
			tx.commit();
		entityManager.close();
			
		entityManagerFactory.close();

	}
}
