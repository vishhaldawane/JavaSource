package com.onetomanybi;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="project_members")
public class ProjectMember   {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="MEM_ID")
	private long memId;

	private BigDecimal age;

	@Column(name="MEMBER_NAME")
	private String memberName;

	//bi-directional many-to-one association to Project
	@ManyToOne
	@JoinColumn(name="EID")
	private Project project;

	public ProjectMember() {
	}

	public long getMemId() {
		return this.memId;
	}

	public void setMemId(long memId) {
		this.memId = memId;
	}

	public BigDecimal getAge() {
		return this.age;
	}

	public void setAge(BigDecimal age) {
		this.age = age;
	}

	public String getMemberName() {
		return this.memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}