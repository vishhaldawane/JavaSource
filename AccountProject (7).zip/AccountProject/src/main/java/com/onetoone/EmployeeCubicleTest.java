package com.onetoone;

import org.junit.Test;

import com.util.BaseDao;

public class EmployeeCubicleTest {

	@Test
	public void addEmp() {
		Employee emp = new Employee();
		emp.setName("Mythili");
		
		new BaseDao().persist(emp);
	}
	
	@Test
	public void addCubicle() {
		Cubicle cub = new Cubicle();
		cub.setFloor("6th Floor");
		
		new BaseDao().persist(cub);
	}
	
	@Test
	public void addEmployeeAlongWithCubicle() {
		Employee emp = new Employee();
		emp.setName("Rajesh"); // 
		
		Cubicle cubicle = new Cubicle();
		cubicle.setFloor("11th Floor");
		
		emp.setAssignedCubicle(cubicle);
		
		new BaseDao().persist(emp);
		
	}
	
	@Test
	public void assignCubicleToEmployee() {
		BaseDao dao = new BaseDao();
		
		Employee emp = dao.find(Employee.class, 13);
		Cubicle cubicle = dao.find(Cubicle.class, 10);
		emp.setAssignedCubicle(cubicle);
		dao.merge(emp); //update query		
	}
}

//tables <-> dao           <-spring-> <--rest--> <--angular-->
//  1         2 test cases
// testAddBus(), testViewBus()  testViewAllBuses
// testFindTicket() testFindBusBasedOnSourceAndLocation()
// testCancelTicket() and so on....45 test cases
