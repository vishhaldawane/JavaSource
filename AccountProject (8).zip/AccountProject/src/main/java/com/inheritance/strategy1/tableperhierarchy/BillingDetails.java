package com.inheritance.strategy1.tableperhierarchy;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity(name="BillingDetails1")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="billing_type", length = 5)
public abstract class BillingDetails {
 //above class cannot be instantiated, hence how it can be persited?
	//instance/object is converted into a row!!!!
	
	@Id //@GeneratedValue
	private int id;
	
	@Column(length=10)
	private String owner;
	
	@Column(length=20)
	private String billingNumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBillingNumber() {
		return billingNumber;
	}
	public void setBillingNumber(String number) {
		this.billingNumber = number;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
}
