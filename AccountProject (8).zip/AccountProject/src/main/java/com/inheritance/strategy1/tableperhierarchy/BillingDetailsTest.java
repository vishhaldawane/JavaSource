package com.inheritance.strategy1.tableperhierarchy;

import java.util.List;

import org.junit.Test;

//import com.inheritance.strategy2.joinedtableperclass.BillingDetails;
import com.util.BaseDao;

public class BillingDetailsTest {

	@Test
	public void testCase1() {
		
		//BillingDetails b = new BillingDetails();
		
		BankAccount bankAcc = new BankAccount();
		bankAcc.setId(77);
		bankAcc.setOwner("Majrul"); //BillingDetails
		bankAcc.setBillingNumber("12345"); //BillingDetails
		bankAcc.setBankName("ICICI Bank"); //BankAccount
 
		CreditCard creditCard = new CreditCard();
		bankAcc.setId(78);
		creditCard.setOwner("Majrul");
		creditCard.setBillingNumber("4129012345678890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2099");
		
		BaseDao dao = new BaseDao();
		dao.merge(bankAcc);
		dao.merge(bankAcc);
		dao.merge(bankAcc);
		
		dao.merge(creditCard);
		dao.merge(creditCard);
		dao.merge(creditCard);
		
	}

	@Test
	public void testCase2() {
		BaseDao dao = new BaseDao();
		List<BillingDetails> list = dao.getAll("BillingDetails1");
		System.out.println(list);
	}
}
