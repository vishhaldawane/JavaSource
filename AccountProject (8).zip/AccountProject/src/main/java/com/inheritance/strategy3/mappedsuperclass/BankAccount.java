package com.inheritance.strategy3.mappedsuperclass;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity(name="BankAccount3")
public class BankAccount extends BillingDetails {

	@Column(length=15)
	private String bankName;
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
}
