package com.inheritance.strategy2.joinedtableperclass;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity(name="BillingDetails2")
@Inheritance(strategy=InheritanceType.JOINED)
public class BillingDetails {

	@Id
	@GeneratedValue
	private int id;
	
	@Column(length=10)
	private String owner;
	
	@Column(length=20)
	private String billingNumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBillingNumber() {
		return billingNumber;
	}
	public void setBillingNumber(String number) {
		this.billingNumber = number;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
}
