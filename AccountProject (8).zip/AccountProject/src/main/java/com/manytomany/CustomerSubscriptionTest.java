package com.manytomany;

import org.junit.Test;

import com.util.BaseDao;

public class CustomerSubscriptionTest {

	@Test
	public void testCase1() {
		BaseDao dao = new BaseDao();
		
		Customer cust = new Customer();
		cust.setId(57);
		cust.setName("Majrul"); cust.setEmail("majrul@rediff.com");
		System.out.println("customer 1 is created...");
		
		dao.merge(cust);
		System.out.println("customer 1 is merged...");
		
		cust = new Customer();
		cust.setId(58);
		cust.setName("Bill"); cust.setEmail("bill@rediff.com");
		System.out.println("customer 2 is created...");
		
		dao.merge(cust);
		System.out.println("customer 2 is merged...");
		
		Subscription subs = new Subscription();
		subs.setId(59);
		subs.setType("audiobk"); subs.setDuration(2);
		System.out.println("Subscription 1 is created...");
		
		dao.merge(subs);
		System.out.println("Subscription 1 is merged...");
		
		
		subs = new Subscription();
		subs.setId(60);
		subs.setType("Movies"); subs.setDuration(3);
		System.out.println("Subscription 2 is created...");
		
		dao.merge(subs);
		System.out.println("Subscription 2 is merged...");
		
		subs = new Subscription();
		subs.setId(60);
		subs.setType("Drama"); subs.setDuration(3);
		System.out.println("Subscription 2 is created...");
		
		dao.merge(subs);
	}
	
	@Test
	public void testCase5() {
		BaseDao dao = new BaseDao();
		
		Subscription subs = new Subscription();
		
		
		subs.setId(61);
		subs.setType("DRAMAS"); 
		subs.setDuration(6);
		System.out.println("Subscription 2 is created...");
		
		dao.merge(subs);
	}
	/* 7 to 8 
	 * 
	 * 40 X 250 grid
	 * 	..	..	..	..	..	..	.			40
1	101	open		    balance		withamt	withdt	currbal		depoAmt
						50000		5000	12-Jan	45000		NA
2	101 with			45000		10000	13-jan	35000		NA
2	101 with			35000		7000	14-jan	28000		Na
2	101 with

3	101 depo			35000		NA		15-Jan	38000		3000
3	101 depo			38000		NA		16-Jan	43000		5000
3	101 depo			43000		NA		17-Jan	45000		2000

4	101 tranf
4	101 tranf
4	101 tranf

5	101 add payee
5	101 add payee
5	101 add payee

6	101 remove a payee
6	101 remove a payee
6	101 remove a payee

7	101 see all payees
7	101 see all payees
7	101 see all payees

8	101 to see mini statement
8	101 to see mini statement
8	101 to see mini statement

9	101 to view balace
9	101 to view balace
9	101 to view balace

25 records for 101
10 X 250

	102
	
	103
	
	110
	
..90	

 fnf
 snf - fd
 tnf - td 
 bcnf - bcnf
 
*/	
	
	@Test
	public void testCase2() {
	//ADD 2 CUSTOMERS(41,42) AND 2 SUBSCRIPTIONS(43,44) AND THEN BELOW CODE
		BaseDao dao = new BaseDao();
		
		Customer cust = dao.find(Customer.class, 58); //angular data -> rest -> spring -> dao -> and then here
		
		Subscription sub = dao.find(Subscription.class,60); //59 2 Book 
		
		cust.getSubscriptions().add(sub);
		dao.merge(cust);
	}
}
