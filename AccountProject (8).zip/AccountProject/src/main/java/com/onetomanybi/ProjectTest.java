package com.onetomanybi;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.util.BaseDao;

public class ProjectTest {

	@Test
	public void testCase1a()
	{
		//Department dept1 = new Department(10,"Admin","Andheri");
		
		BaseDao dao = new BaseDao();
		
		Project project = new Project();
		
		project.setName("HAMID");		project.setDone("YES");
		project.setProject("BUS");		BigDecimal bd = new BigDecimal(9);
		project.setStatus(bd);
		
		
		Set<ProjectMember> members= new HashSet<ProjectMember>();
		
		ProjectMember member1 = new ProjectMember();
		ProjectMember member2 = new ProjectMember();
		ProjectMember member3 = new ProjectMember();
		
		member1.setMemberName("SUBIN");		member1.setAge(new BigDecimal(22)); 		member1.setProject(project);
		member2.setMemberName("AWTANSH");		member2.setAge(new BigDecimal(22));		member2.setProject(project);
		member3.setMemberName("MIT");		member3.setAge(new BigDecimal(22)); 		member3.setProject(project);
		
		members.add(member1); //eachmember is added to the set
		members.add(member2); //eachmember is added to the set
		members.add(member3); //eachmember is added to the set
		
		
		project.setProjectMember(members); //finally teh set is added to the project
		
		dao.persist(project); //persisting the project will add the members too
		
		
		
	}
	
	@Test
	public void testCase2() {
		BaseDao dao = new BaseDao();
		long l= 80;
		ProjectMember member= dao.find(ProjectMember.class, l);
		System.out.println("Member id   : "+member.getMemId());
		System.out.println("Member Name : "+member.getMemberName());
		System.out.println("Member Age  : "+member.getAge());
	}

	@Test
	public void testCase3() {
		BaseDao dao = new BaseDao();
		long l= 112;
		ProjectMember member= dao.find(ProjectMember.class, l);
		System.out.println("Member id   : "+member.getMemId());
		System.out.println("Member Name : "+member.getMemberName());
		System.out.println("Member Age  : "+member.getAge());
		
		Project proj = member.getProject();
		System.out.println("Project Empno  : "+proj.getEmpno());
		System.out.println("Project Lead   : "+proj.getName());
		System.out.println("Project Name   : "+proj.getProject());
		System.out.println("Project Done   : "+proj.getDone());
		System.out.println("Project Status : "+proj.getStatus());
	}

	@Test
	public void testCase4() {
		BaseDao dao = new BaseDao();
		long l= 104;
		Project proj= dao.find(Project.class, l);

		System.out.println("Project Empno  : "+proj.getEmpno());
		System.out.println("Project Lead   : "+proj.getName());
		System.out.println("Project Name   : "+proj.getProject());
		System.out.println("Project Done   : "+proj.getDone());
		System.out.println("Project Status : "+proj.getStatus());
		
		System.out.println("-----------------");
		
		Set<ProjectMember> projMembers = proj.getProjectMembers();
		
		for (ProjectMember member : projMembers) {
				System.out.println("Member id   : "+member.getMemId());
				System.out.println("Member Name : "+member.getMemberName());
				System.out.println("Member Age  : "+member.getAge());
				System.out.println("-----------------");
		}
	}
	
	/*
	 * @Test public void testCase1() {
	 * 
	 * Department dept = new Department(); dept.setDeptno(30);
	 * dept.setName("Sales"); dept.setLocation("Kalyan, Thane");
	 * 
	 * BaseDao dao = new BaseDao(); dao.merge(dept); }
	 * 
	 * @Test public void testCase2() { BaseDao dao = new BaseDao();
	 * 
	 * //search for an existing department Department dept = (Department)
	 * dao.getReference(Department.class, 10);
	 * 
	 * Employee emp = new Employee(); emp.setEmpno(1002);
	 * emp.setName("Majrul Ansari2"); emp.setSalary(1002.0);
	 * 
	 * emp.setDept(dept); //assign that dept for this new emp
	 * 
	 * dao.persist(emp); //store this new emp for that dept }
	 * 
	 * @Test public void testCase3() { BaseDao dao = new BaseDao(); Department dept
	 * = (Department) dao.find(Department.class, 10);
	 * System.out.println("dept "+dept.getName()); }
	 */}





