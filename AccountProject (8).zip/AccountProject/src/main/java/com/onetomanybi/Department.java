package com.onetomanybi;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;


@Entity(name = "Department2")
public class Department {

	@Id private int deptno;
	@Column(length=15)  private String name;
	@Column(length=15) private String location;
	
	
	//below data member 'employees' is a bond between CurrentClass 
	//'Department' and the [employees's data typed class]'-> Employee
	
	@OneToMany(mappedBy="dept",fetch = FetchType.EAGER, cascade=CascadeType.ALL)
	@OrderBy("name asc")
	private Set<Employee> employees; //hence u can acquire all of
	//the employees(select * from employee2 with where clause of deptno)
	// by invoking the [getEmployees()] method
	
	public Set<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	public Department(int deptno, String name, String location) {
		super();
		this.deptno = deptno;
		this.name = name;
		this.location = location;
	}
	public Department() {
		super();
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
