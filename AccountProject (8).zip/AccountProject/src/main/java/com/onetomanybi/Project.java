package com.onetomanybi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="project")
public class Project   {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long empno;

	private String done;

	private String name;

	private String project;

	private BigDecimal status;

	//bi-directional many-to-one association to ProjectMember
	@OneToMany(mappedBy="project", fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private Set<ProjectMember> projectMember;

	public Project() {
	}

	public long getEmpno() {
		return this.empno;
	}

	public void setEmpno(long empno) {
		this.empno = empno;
	}

	public String getDone() {
		return this.done;
	}

	public void setDone(String done) {
		this.done = done;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProject() {
		return this.project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public BigDecimal getStatus() {
		return this.status;
	}

	public void setStatus(BigDecimal status) {
		this.status = status;
	}

	public Set<ProjectMember> getProjectMembers() {
		return this.projectMember;
	}

	public void setProjectMember(Set<ProjectMember> projectMembers) {
		this.projectMember = projectMembers;
	}

	public ProjectMember addProjectMember(ProjectMember projectMember) {
		getProjectMembers().add(projectMember);
		projectMember.setProject(this);

		return projectMember;
	}

	public ProjectMember removeProjectMember(ProjectMember projectMember) {
		getProjectMembers().remove(projectMember);
		projectMember.setProject(null);

		return projectMember;
	}

}