package com.myservice;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// http://ip:port/DeptManagement/DeptService/rest/depts
//intermediate program as 
//ServletContainer from jersey framework

/*for REST
 *                         web.xml
 *             ProjectFolder   |   @Path       
http://ip:port/DeptManagement/rest/depts 		<-GET
http://ip:port/DeptManagement/rest/depts/10 	<-GET
http://ip:port/DeptManagement/rest/depts/10 	<-DELETE

http://ip:port/DeptManagement/rest/depts 		<-POST
http://ip:port/DeptManagement/rest/depts 		<-PUT


*/
//baseUrl: string = 'http://localhost:8085/DeptManagement/rest/DepartmentService/';
//getDepts/   getDept/      addDept/  updateDept/  deleteDept/
@Path("/DepartmentService")
public class DeptService {
	
	DeptDao dd = new DeptDao();

	@GET
	@Path("/getDepts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Dept> getDepts() {
		System.out.println("Inside /getDepts/");
		return dd.getAllDepts();
	}  
	
	 
	@GET
	@Path("/getDept/{dno}")
	@Produces(MediaType.APPLICATION_JSON)
	public Dept getDept(@PathParam("dno") int dno) {
		System.out.println("Inside /getDept/{dno} = "+dno);
		Dept d = dd.getDept(dno);
		System.out.println("d = "+d);
		return d;
	}
	
	
	@POST
	@Path("/addDept")
	@Consumes(MediaType.APPLICATION_JSON)
	public void addDepts(Dept dept) {
		System.out.println("Inside /addDept : "+dept);
		dd.insertIntoDept(dept);
	}
	
	@PUT
	@Path("/updateDept")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateDept(Dept dept) {
		System.out.println("Inside /updateDept : "+dept);
		dd.updateDept(dept);
	}

	@DELETE
	@Path("/deleteDept/{dno}")
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteDept(@PathParam("dno") int dno) {
		System.out.println("Inside /deleteDept/{dno} : "+dno);
		dd.deleteDept(dno);
	}
}


