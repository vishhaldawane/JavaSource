package com.myservice;

//import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement(name = "dept" )
public class Dept {
	
	@Override
	public String toString() {
		return "Dept [deptNumber=" + deptNumber + ", deptName=" + deptName + ", deptLocation=" + deptLocation + "]";
	}

	private int deptNumber;
	private String deptName;
	private String deptLocation;
	
	public int getDeptNumber() {
		System.out.println("getDeptNumber()");
		return deptNumber;
	}

	//@XmlElement
	public void setDeptNumber(int deptNumber) {
		this.deptNumber = deptNumber;
	}

	public String getDeptName() {
		System.out.println("getDeptName()");
		return deptName;
	}

	//@XmlElement
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		System.out.println("getDeptLocation()");
		return deptLocation;
	}

	//@XmlElement
	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	
	
	public Dept() {
		System.out.println("Dept() ctor..");
	}

	public Dept(int deptNumber, String deptName, String deptLocation) {
		super();
		this.deptNumber = deptNumber;
		this.deptName = deptName;
		this.deptLocation = deptLocation;
	}
	
}
