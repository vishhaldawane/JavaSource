package com.forms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FormsServlet extends HttpServlet {
	   
    
    public FormsServlet() {
        super();
    
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in doGet");
		doMyProcessing(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in doPost()");
		doMyProcessing(request, response);
		
	}
	
	protected void doMyProcessing(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("You are in doMyProcessing()..");
		
	/*	String fn = request.getParameter("firstName");
		String up = request.getParameter("userPass");
		String ea = request.getParameter("emailAddress");
		*/
		
		//this single function will retrieve all 
		//the html variable names - firstName, userPass, emailAddress 
		//(AND NOT THEIR VALUES)
		
		PrintWriter out = response.getWriter();
		/*
		style='color:red'
		style='{color:red}'
		styles='color:red'
		style='color=red'
		*/
		
		Enumeration<String> allHeaderNames = request.getHeaderNames();
		out.println("<table border=5 cellspacing=10 cellpadding=10 style='color:blue'>");
		while(allHeaderNames.hasMoreElements()) {
			String headerName = allHeaderNames.nextElement();
			out.println("<tr>");
			out.println("<td>Header name</td><td>"+headerName+"</td>");
			String headerValue = request.getHeader(headerName);
			out.println("<td>Header value</td><td>"+headerValue+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
		
		
		
		Enumeration<String> allNames = request.getParameterNames();
		
		out.println("<table border=5 cellspacing=10 cellpadding=10>");
		while(allNames.hasMoreElements()) {
			String paraName = allNames.nextElement();
			out.println("<tr>");
			out.println("<td>Parameter name</td><td>"+paraName+"</td>");
			String paraValue = request.getParameter(paraName);
			out.println("<td>Parameter value</td><td>"+paraValue+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
		/*PrintWriter pw = response.getWriter();
		pw.println("<table border=5>");
			pw.println("<tr>"); //on mute
				pw.println("<td>FirstName</td><td>"+fn+"</td>");
			pw.println("</tr>");
			
			
			pw.println("<tr>");
				pw.println("<td>Password</td><td>"+up+"</td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
				pw.println("<td>EmailAddress</td><td>"+ea+"</td>");
			pw.println("</tr>");
		pw.println("</table>");
		*/
	}

	
}
