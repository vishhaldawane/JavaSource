package com.myairline;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class RegisterUserServlet
 */
public class RegisterUserServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public RegisterUserServlet() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("RegisterUserServlet() constructor...");
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("\tRegisterUserServlet: service is called..");
		PrintWriter pw = response.getWriter();
		pw.println("<h2> registration is done......</h2>");
		pw.println("<a href='http://localhost:8085/MyAirline/'>Home</a>");
	}

}
