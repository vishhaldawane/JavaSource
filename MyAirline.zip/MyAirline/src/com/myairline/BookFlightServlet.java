package com.myairline;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class BookFlightServlet extends GenericServlet {
	
	 public BookFlightServlet() {
        super();
        System.out.println("BookFlightServlet() constructed....");
    }

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("\tBookFlightServlet: service is called..");
		PrintWriter pw = response.getWriter();
		pw.println("<h2> Flight is booked...</h2>");
		pw.println("<a href='http://localhost:8085/MyAirline/'>Home</a>");
	}

}
