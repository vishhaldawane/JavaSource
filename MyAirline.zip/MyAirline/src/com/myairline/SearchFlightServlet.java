package com.myairline;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class SearchFlightServlet
 */
public class SearchFlightServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public SearchFlightServlet() {
        super();
        System.out.println("SearchFlightServlet() constructor....");
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("\tSearchFlightServlet: service is called..");
		PrintWriter pw = response.getWriter();
		pw.println("<h2> Flight is being searched...</h2>");
		pw.println("<a href='http://localhost:8085/MyAirline/'>Home</a>");
	}

}
