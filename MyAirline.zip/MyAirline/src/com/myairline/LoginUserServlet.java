package com.myairline;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet implementation class LoginUserServlet
 */
public class LoginUserServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public LoginUserServlet() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("LoginUserServlet() constructor....");
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("\tLoginUserServlet: service is called..");
		PrintWriter pw = response.getWriter();
		pw.println("<h2> User is logging in...</h2>");
		pw.println("<a href='http://localhost:8085/MyAirline/'>Home</a>");
	}

}
