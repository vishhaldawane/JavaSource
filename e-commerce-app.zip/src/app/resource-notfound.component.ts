import { Component } from '@angular/core';

@Component({
    templateUrl: "./resource-notfound.component.html"
})
export class ResourceNotFoundComponent {

}