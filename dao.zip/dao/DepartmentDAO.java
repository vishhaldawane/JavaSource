package com.bank.dao;

import java.util.List;

import com.bank.Department;

public interface DepartmentDAO {
	void insertDepartment(Department deptObj); //C
	List<Department> getDepartments(); 		   //RA
	Department       getDepartment(int dno);   //R
	void updateDepartment(Department deptObj); //U
	void deleteDepartment(Department deptObj); //D
}
