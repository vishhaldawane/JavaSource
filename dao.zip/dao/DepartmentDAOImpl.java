package com.bank.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.bank.Department;

public class DepartmentDAOImpl implements DepartmentDAO {
	
	Configuration config ;
	SessionFactory factory ;
	
	public DepartmentDAOImpl() {
		
		System.out.println("DepartmentDAOImpl() ctor...");
		config = new Configuration();
		System.out.println("=> Configuration created..."+config);
		factory = config.configure("hibernate.cfg.xml").buildSessionFactory();
		System.out.println("=> Factory created : "+factory);
	}
	
	public void insertDepartment(Department deptObj) {
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		mySession.save(deptObj);
		myTransaction.commit();

	}

	public List<Department> getDepartments() {
		List<Department> deptList = new ArrayList<Department>();
		Session mySession = factory.getCurrentSession();
		String myQueryString = "from Department";//select * from dept20;
		
		Transaction myTransaction = mySession.beginTransaction();
			Query<Department> theHqlQuery = mySession.createQuery(myQueryString);
			System.out.println("theHqlQuery : "+theHqlQuery);
			deptList =	theHqlQuery.getResultList();
		myTransaction.commit();
		
		return deptList;
	}

	public Department getDepartment(int dno) {
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		return mySession.get(Department.class, dno);
		//Department.class means, class is the static variable
						//of type Class 
	}

	public void updateDepartment(Department deptObj) {
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		mySession.update(deptObj);
		myTransaction.commit();
	}

	public void deleteDepartment(Department deptObj) {
		Session mySession = factory.getCurrentSession();
		System.out.println("=> Got the session : "+mySession);
		Transaction myTransaction = mySession.beginTransaction();
		System.out.println("=> Started the transaction : "+myTransaction);
		mySession.delete(deptObj);
		myTransaction.commit();


	}

}
