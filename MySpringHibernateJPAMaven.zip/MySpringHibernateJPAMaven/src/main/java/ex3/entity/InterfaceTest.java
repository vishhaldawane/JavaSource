package ex3.entity;

interface WithdrawService
{
	void withdraw(float a);
}
interface DepositService
{
	void deposit(float a);
}


class SavingsAccount implements WithdrawService,DepositService
{
	private float balance;
	
	public SavingsAccount(float i) {
		balance = i;
	}
	public void withdraw(float amt) {
		System.out.println("Withdrawing from SavingsAccount...");
		balance  = balance - amt;
		
	}
	public void deposit(float amt) {
		System.out.println("Depositing in SavingsAccount...");
		balance  = balance + amt;
	}
	@Override
	public String toString() {
		return "Savings Acc Bal : "+balance;
	}
}

class CurrentAccount implements WithdrawService,DepositService
{
	private float balance;
	public CurrentAccount(float i) {
		balance = i;
	}
	public void withdraw(float amt) {
		System.out.println("Withdrawing from CurrentAccount...");
		balance  = balance - amt;
	}
	
	public void deposit(float amt) {
		System.out.println("Depositing in CurrentAccount...");
		balance  = balance + amt;
	}
	@Override
	public String toString() {
		return "Current Ac  Bal : "+balance;
	}
}
				//who
		//when			where
//why(analysis)		what (info)		how(coding)			

interface FundTransferService
{
	public boolean isPayeeAdded();
	public void viewPayee();
	public void addPayee();
	public void transferFunds(WithdrawService sourceRef, DepositService targetRef, float amountToTrasfer);
}

class FundTransferServiceImpl implements FundTransferService
{								// first handle is of source   second handle is of target
	public void transferFunds(WithdrawService sourceRef, DepositService targetRef, float amountToTrasfer)
	{
		System.out.println("Transferring....Fund....."+amountToTrasfer);
		sourceRef.withdraw(amountToTrasfer);
	//	sourceRef.deposit(amountToTrasfer);
		
		targetRef.deposit(amountToTrasfer);
		//targetRef.withdraw(amountToTrasfer);
		
		System.out.println("Fund Transferrred........"+amountToTrasfer);
	}
	public boolean isPayeeAdded() { return false;}
	public void viewPayee() { }
	public void addPayee() { }
}

public class InterfaceTest {
	public static void main(String[] args) {
		CurrentAccount cur = new CurrentAccount(500000);
		SavingsAccount sav = new SavingsAccount(35000);
		
		System.out.println("cur "+cur);
		System.out.println("sav "+sav);
		
		FundTransferService fundTransferService = new FundTransferServiceImpl();
		fundTransferService.isPayeeAdded();
		fundTransferService.viewPayee();
		fundTransferService.transferFunds(cur, sav, 45000);

		
		System.out.println("cur "+cur);
		System.out.println("sav "+sav);
		
	}
}
