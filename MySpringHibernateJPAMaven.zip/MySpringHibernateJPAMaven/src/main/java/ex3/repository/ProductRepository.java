package ex3.repository;

public interface ProductRepository {
	public void reduceStock(int productId, int quantity);
}
