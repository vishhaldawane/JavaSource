package ex3.repository.impl;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ex3.repository.ProductRepository;

@Repository
public class ProductRepositoryImpl implements ProductRepository {

	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		System.out.println("==> setDataSource(DataSource)....");
		//instantiate this ref to point to DataSource
		jdbcTemplate = new JdbcTemplate(dataSource);
		
	}
	
	@Transactional
	public void reduceStock(int productId, int quantity) {
		String sqlQuery = "update tx_products set quantity=quantity-? where productid=?";
		
		System.out.println("JDBC : "+sqlQuery); //hibernate would show QUERIES VIA SHOW_SQL=TRUE PROPERTY  
		jdbcTemplate.update(sqlQuery,quantity,productId);
	}

}
