package ex3.repository.impl;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ex3.entity.Order;
import ex3.repository.OrderRepository;

@Repository
public class OrderRepositoryImpl 
extends AbstractJpaRepository 
implements OrderRepository {

	@Transactional
	public void processOrder(Order ord) {
		
		super.getEntityManager().persist(ord);

	}

}
