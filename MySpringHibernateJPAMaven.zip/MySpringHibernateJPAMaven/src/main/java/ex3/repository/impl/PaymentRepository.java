package ex3.repository.impl;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ex3.entity.Payment;

@Repository
public class PaymentRepository extends AbstractJpaRepository implements ex3.repository.PaymentRepository {

	@Transactional
	public void store(Payment payDetails) {
		super.getEntityManager().persist(payDetails);
	}

}
