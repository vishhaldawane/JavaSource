package ex3.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;



public abstract class AbstractJpaRepository {
	
		@PersistenceContext(unitName = "Spring-JPA")
		private EntityManager entityManager;

		//@Autowired
		/*public void setEntityManager(EntityManager entityManager) {
			this.entityManager = entityManager;
		}*/
		
		public EntityManager getEntityManager() {
			return entityManager;
		}

		

		
	
}
