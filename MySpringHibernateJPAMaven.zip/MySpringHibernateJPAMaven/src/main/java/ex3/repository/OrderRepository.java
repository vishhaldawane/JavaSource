package ex3.repository;

import ex3.entity.Order;

public interface OrderRepository {
	public void processOrder(Order ord);
}
