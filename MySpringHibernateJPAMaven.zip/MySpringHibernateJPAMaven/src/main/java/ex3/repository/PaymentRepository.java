package ex3.repository;

import ex3.entity.Payment;

public interface PaymentRepository {
	public void store(Payment payDetails);
}
