package ex3.service;

import org.springframework.transaction.annotation.Transactional;

import ex3.entity.Order;

public interface OnlineShoppingService {

	@Transactional
	public void placeOrder(Order ord);
}
