package ex3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ex3.entity.Order;
import ex3.entity.Payment;
import ex3.repository.OrderRepository;
import ex3.repository.PaymentRepository;
import ex3.repository.ProductRepository;

@Service
public class OnlineShoppingServiceImpl implements OnlineShoppingService {

	
	private OrderRepository orderRepository;
	private PaymentRepository paymentRepository;
	private ProductRepository productRepository;
	
	@Autowired
	public void init(OrderRepository orderRepository,PaymentRepository paymentRepository,ProductRepository productRepository)
	{
		this.orderRepository=orderRepository;
		this.paymentRepository=paymentRepository;
		this.productRepository=productRepository;
	}
	
	//@Transactional
	public void placeOrder(Order ord) 
	{
		orderRepository.processOrder(ord); //save the ord info in DB
		
		Payment paymentDetails = new Payment();
		paymentDetails.setOrderId(ord.getOrderid());
		paymentDetails.setAmount(ord.getPrice() * ord.getQuantity());

		paymentRepository.store(paymentDetails); // save the paymentDetails in DB
		
		//now lets update the stock
		productRepository.reduceStock(ord.getProductid(), ord.getQuantity());
		
		System.out.println("DONE");
	}

}
