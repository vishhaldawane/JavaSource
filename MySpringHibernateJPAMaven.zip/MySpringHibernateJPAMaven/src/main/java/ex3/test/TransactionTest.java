package ex3.test;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ex3.entity.Order;
import ex3.service.OnlineShoppingService;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:ex3/myspring.xml")
public class TransactionTest {
	
	@Autowired
	OnlineShoppingService onlineShopping;
	
	@Test
	public void testCase1() {
		Order ord = new Order();
		ord.setProductid(123);
		ord.setPrice(750);
		ord.setQuantity(5);
		
		onlineShopping.placeOrder(ord); // will initiate 3 repos
		
		System.out.println("End of Test");
	}
	
}
