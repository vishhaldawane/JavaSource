package ex1;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:ex1/myspring.xml")
public class SpringORMTest1 {
	
	@Autowired
	ProductRepository productRepository; 
	
	@Test
	public void testCase1() {
	
		//ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		//System.out.println("container "+container);
		
		//ProductRepository productRepository = (HibernateProductRepository) container.getBean("productRepository");
		System.out.println("Product repo : "+productRepository);
		
		Product prod = new Product();
		prod.setProductName("TENNIS Balls");
		prod.setDescription("Sports");
		prod.setPrice(300.00);
		prod.setQuantity(3);

		productRepository.add(prod); 

		
		System.out.println("Done");
	}
	
}
