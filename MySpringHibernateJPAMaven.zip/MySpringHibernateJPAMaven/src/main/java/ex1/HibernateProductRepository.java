package ex1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

				//Car
public class HibernateProductRepository implements ProductRepository {

			//Engine		
	private SessionFactory sessionFactory; //its null here
	
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		System.out.println("setSessionFactory(SessionFactory)");
		this.sessionFactory = sessionFactory; //not its not null
	}
	//spring + hibernate + spring tm manager
	
	
	
	public void add(Product product) {
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.save(product); //persistence 
		tx.commit();
	}


	public Product get(int productId) {
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();

		Product product = session.get(Product.class, productId);
		
		tx.commit();
		return product;
	}

	//spring data jpa
	
	public List<Product> getAll() {
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();

		List<Product> products = session.createQuery("from products").getResultList();
		
		tx.commit();
		
		return products;
	}

}
