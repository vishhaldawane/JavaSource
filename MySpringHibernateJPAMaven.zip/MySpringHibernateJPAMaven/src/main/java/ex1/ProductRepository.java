package ex1;


import java.util.List;

/*
 * 	John should identify
 * 	various interfaces for DAO
 *  as per teh project case study
 *  
 *  			Banking 
 *  AccountOpening	FundTransferModule AccountStatement
 *  4				4					4
 *  
 *  3 nitish		3 sneha  3 awtansh	3 shubham
 *  
 *  				payee <-- table
 *  			
 *  				Payee <-- class
 *  
 *  		PayeeRepository
 *  			void addPayee(Payee p);
 *  			Payee getPayee(int payeeId)
 *  			List<Payee> getPayees();
 *  			void deletePayee(int payeeId)
 *  			
 *  		PayeeRepositoryImpl
 */
//john hand over this interface to
//mit, and expects the implementation

public interface ProductRepository {
	public void add(Product product);
	public Product get(int productId);
	public List<Product> getAll();
	//7 methods declared
}
