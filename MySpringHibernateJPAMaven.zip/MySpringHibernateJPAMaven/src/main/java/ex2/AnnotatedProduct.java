package ex2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="anno_product")
public class AnnotatedProduct {

	@Id
	@GeneratedValue
	private int productId;
	
	@Column(length=20)
	private String productName;
	
	@Column(length=20)
	private String description;
	
	private double price;
	private int quantity;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "AnnotatedProduct [productId=" + productId + ", productName=" + productName + ", description="
				+ description + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
}
