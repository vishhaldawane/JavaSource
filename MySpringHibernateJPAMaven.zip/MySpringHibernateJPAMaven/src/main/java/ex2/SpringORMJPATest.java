package ex2;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:ex2/myspring.xml")
public class SpringORMJPATest {
	
	@Autowired
	ProductRepository annoProductRepository; 
	
	@Test
	public void testCase1() {
	
		//ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		//System.out.println("container "+container);
		
		//ProductRepository productRepository = (HibernateProductRepository) container.getBean("productRepository");
		System.out.println("Product repo : "+annoProductRepository);
		
		AnnotatedProduct prod = new AnnotatedProduct();
		prod.setProductName("FootBall");
		prod.setDescription("Sports");
		prod.setPrice(1300.00);
		prod.setQuantity(3);

		annoProductRepository.add(prod); 

		
		System.out.println("Done");
	}
	
}
