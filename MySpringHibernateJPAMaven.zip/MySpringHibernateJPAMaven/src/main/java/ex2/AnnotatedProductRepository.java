package ex2;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

public class AnnotatedProductRepository implements ProductRepository {


	@PersistenceContext(unitName = "Spring-JPA")
	private EntityManager entityManager;

	@Transactional  //let this method participate in TM
	public void add(AnnotatedProduct product) {
		entityManager.persist(product);
	}

	
	@Transactional
	public AnnotatedProduct  get(int productId) {
		AnnotatedProduct product = entityManager.find(AnnotatedProduct.class, productId);
		return product;
	}

	@Transactional
	public List<AnnotatedProduct > getAll() {
		List<AnnotatedProduct> products = entityManager.createQuery("from products").getResultList();
		return products;
	}

}
