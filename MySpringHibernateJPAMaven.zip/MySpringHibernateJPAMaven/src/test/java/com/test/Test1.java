package com.test;

import org.junit.jupiter.api.Test;

public class Test1 {
	
	@Test
	public void testCase()
	{
		System.out.println("Test1");
	}
}
