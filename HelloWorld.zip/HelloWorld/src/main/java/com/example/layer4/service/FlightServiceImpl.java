package com.example.layer4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.layer2.entity.Flight;
import com.example.layer3.repository.FlightRepository;
@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepository; //service is talking to repository
	
	@Override
	public List<Flight> getAllFlightsService() { //service invoking repository
		List<Flight> listOfFlights = null;
		//take some business decisionshere 
		//take some business decisionshere 
		listOfFlights = flightRepository.getAllFlights();
		//take some business decisionshere 
		//take some business decisionshere 
		return listOfFlights;
	}

}
