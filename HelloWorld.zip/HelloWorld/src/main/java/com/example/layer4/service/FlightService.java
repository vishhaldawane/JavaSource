package com.example.layer4.service;

import java.util.List;

import com.example.layer2.entity.Flight;

public interface FlightService {
	List<Flight> getAllFlightsService();
}
