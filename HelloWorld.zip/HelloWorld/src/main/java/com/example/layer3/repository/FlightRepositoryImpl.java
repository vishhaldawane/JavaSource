package com.example.layer3.repository;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.layer2.entity.Flight;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public class FlightRepositoryImpl implements FlightRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public List<Flight> getAllFlights() {
		Query query = entityManager.createQuery(" from Flight");
		List<Flight> flightList = query.getResultList();
		return flightList;
	}

}
