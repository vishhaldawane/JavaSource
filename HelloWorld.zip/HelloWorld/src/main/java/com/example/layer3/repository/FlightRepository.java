package com.example.layer3.repository;

import java.util.List;

import com.example.layer2.entity.Flight;

public interface FlightRepository { // we can call it repo now instead of DAO
	List<Flight> getAllFlights();
}
