package com.example.layer5.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.layer2.entity.Flight;
import com.example.layer4.service.FlightService;

@Controller
public class FlightController {
	
	@Autowired
	FlightService flightService; //controller is talking to service

	@RequestMapping("/getFlights")
	@ResponseBody
	public String getAllFlights() {
		List<Flight> allFlights = flightService.getAllFlightsService();
		return  "<h1>Showing all Flights </h1>";
	}

	/*
	@RequestMapping("/login")
	@ResponseBody
	public String loginTheUser() {
		//u may connect to a database via dao
		return  "<h2>  Lets Sign In </h2>";
	}
	
	@RequestMapping("/register")
	@ResponseBody
	public String registerTheUser() {
		//u may connect to a database via dao
		return  "<h2>  Lets Sign Up </h2>";
	}
	*/
}
